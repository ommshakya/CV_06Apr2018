# -*- coding: utf-8 -*-
"""
Created on Thu Mar 29 14:14:09 2018

@author: OmPrakash.Shakya
"""
#Import the required libraries/packages
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


#Set the current working directories
os.getcwd()
os.chdir('D:\z.Oms\Learn.Python\LoanPrediction')
os.getcwd()

#List all the files of current working directory
for file in os.listdir(os.getcwd()):
    print(file)

#Read the 'iris-data.csv' file
iris_data = pd.read_csv('iris-data.csv')










    