# -*- coding: utf-8 -*-
"""
Created on Wed Mar 28 16:34:04 2018
https://github.com/rhiever/Data-Analysis-and-Machine-Learning-Projects/blob/master/example-data-science-notebook/Example%20Machine%20Learning%20Notebook.ipynb
http://pandas.pydata.org/pandas-docs/stable/tutorials.html

Further reading
[ go back to the top ]

This notebook covers a broad variety of topics but skips over many of the specifics. If you're looking to dive deeper into a particular topic, here's some recommended reading.

Data Science: William Chen compiled a list of free books for newcomers to Data Science, ranging from the basics of R & Python to Machine Learning to interviews and advice from prominent data scientists.

Machine Learning: /r/MachineLearning has a useful Wiki page containing links to online courses, books, data sets, etc. for Machine Learning. There's also a curated list of Machine Learning frameworks, libraries, and software sorted by language.

Unit testing: Dive Into Python 3 has a great walkthrough of unit testing in Python, how it works, and how it should be used

pandas has several tutorials covering its myriad features.

scikit-learn has a bunch of tutorials for those looking to learn Machine Learning in Python. Andreas Mueller's scikit-learn workshop materials are top-notch and freely available.

matplotlib has many books, videos, and tutorials to teach plotting in Python.

Seaborn has a basic tutorial covering most of the statistical plotting features.



@author: OmPrakash.Shakya
"""

#Import the required libraries/packages
import os
import pandas as pd
#import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb
%matplotlib inline


#################################### Step 1: Answering the question ###############################
#The first step to any data analysis project is to define the question or problem we're looking to solve, and to define a measure (or set of measures) for our success at solving that task. The data analysis checklist has us answer a handful of questions to accomplish that, so let's work through those questions.
#Did you specify the type of data analytic question (e.g. exploration, association causality) before touching the data?
#We're trying to classify the species (i.e., class) of the flower based on four measurements that we're provided: sepal length, sepal width, petal length, and petal width.
#Did you define the metric for success before beginning?
#Let's do that now. Since we're performing classification, we can use accuracy — the fraction of correctly classified flowers — to quantify how well our model is performing. Our company's Head of Data has told us that we should achieve at least 90% accuracy.
#Did you understand the context for the question and the scientific or business application?
#We're building part of a data analysis pipeline for a smartphone app that will be able to classify the species of flowers from pictures taken on the smartphone. In the future, this pipeline will be connected to another pipeline that automatically measures from pictures the traits we're using to perform this classification.
#Did you record the experimental design?
#Our company's Head of Data has told us that the field researchers are hand-measuring 50 randomly-sampled flowers of each species using a standardized methodology. The field researchers take pictures of each flower they sample from pre-defined angles so the measurements and species can be confirmed by the other field researchers at a later point. At the end of each day, the data is compiled and stored on a private company GitHub repository.
#Did you consider whether the question could be answered with the available data?
#The data set we currently have is only for three types of Iris flowers. The model built off of this data set will only work for those Iris flowers, so we will need more data to create a general flower classifier.
#################################### Step 2: Checking the data ##################################
#Set the current working directories
os.getcwd()
os.chdir('D:\z.Oms\Learn.Python\Iris')
os.getcwd()

#List all the files of current working directory
for file in os.listdir(os.getcwd()):
    print(file)

#Read the 'iris-data.csv' file
iris_data = pd.read_csv('iris-data.csv')

################ check missing values ################
# check if the dataframe has any missing values
iris_data.isnull().values.any()

# check there are how many rows that have missing values per column
iris_data.isnull().sum()

# total number of missing values
iris_data.isnull().sum().sum()

# get the columns which has missing values
null_columns = iris_data.columns[iris_data.isnull().any()]
for col in null_columns:
    print(col)

# list the rows having missing values    
iris_data[iris_data.isnull().any(axis = 1)]

################ read the file with missing values specified ################
iris_data = pd.read_csv('iris-data.csv', na_values=['NA'])
# Look at few records
iris_data.describe()

# We have to temporarily drop the rows with 'NA' values
# because the Seaborn plotting function does not know
# what to do with them
sb.pairplot(iris_data.dropna(), hue = 'class')

## from the above plot we identified the following errors
#1. There are five classes when there should only be three, meaning there were some coding errors.
#2. There are some clear outliers in the measurements that may be erroneous: 
#one sepal_width_cm entry for Iris-setosa falls well outside its normal range, 
#and several sepal_length_cm entries for Iris-versicolor are near-zero for some reason.
#3. We had to drop those rows with missing values.

################## Step 3: Tidying the data #######################################
################## So let resolve thorse errore one by one ######################

#1.There are five classes when there should only be three, meaning there were some coding errors.

iris_data.loc[iris_data['class'] == 'versicolor', 'class'] = 'Iris-versicolor'
iris_data.loc[iris_data['class'] == 'Iris-setossa', 'class'] = 'Iris-setosa'

iris_data['class'].unique()

#2.0 Remove outliers
# From the below histogram it is clear that there are some outliers 'sepal_width_cm' < 2.5
iris_data.loc[iris_data['class'] == 'Iris-setosa', 'sepal_width_cm'].hist()

# So we need to exclude those records,
# This line drops any 'Iris-setosa' rows with a separal width less than 2.5 cm
iris_data = iris_data.loc[(iris_data['class'] != 'Iris-setosa') | (iris_data['sepal_width_cm'] >= 2.5)]

# Again see the histogram if there are any more outliers
iris_data.loc[iris_data['class'] == 'Iris-setosa', 'sepal_width_cm'].hist()

#2.1 The next data issue to address is the several near-zero sepal lengths for the Iris-versicolor rows. 
#Let's take a look at those rows.
iris_data.loc[(iris_data['class'] == 'Iris-versicolor') &
              (iris_data['sepal_length_cm'] < 1.0)]


iris_data.loc[iris_data['class'] == 'Iris-versicolor', 'sepal_length_cm'].hist()
#How about that? All of these near-zero sepal_length_cm entries seem to be off by two orders of magnitude, 
#as if they had been recorded in meters instead of centimeters.

#After some brief correspondence with the field researchers, we find that one of them forgot to convert 
#those measurements to centimeters. Let's do that for them.
iris_data.loc[(iris_data['class'] == 'Iris-versicolor') &
              (iris_data['sepal_length_cm'] < 1.0),
              'sepal_length_cm'] *= 100.0

iris_data.loc[iris_data['class'] == 'Iris-versicolor', 'sepal_length_cm'].hist()

# 3. We had to drop those rows with missing values.
# Let's take a look at the rows with missing values:

iris_data.loc[(iris_data['sepal_length_cm'].isnull()) |
              (iris_data['sepal_width_cm'].isnull()) |
              (iris_data['petal_length_cm'].isnull()) |
              (iris_data['petal_width_cm'].isnull())]

# Instead of removing the records with missing values, it is good to do mean imputation
iris_data.loc[iris_data['class'] == 'Iris-setosa', 'petal_width_cm'].hist()
average_petal_width = iris_data.loc[iris_data['class'] == 'Iris-setosa', 'petal_width_cm'].mean()


iris_data.loc[(iris_data['class'] == 'Iris-setosa') &
              (iris_data['petal_width_cm'].isnull()),
              'petal_width_cm'] = average_petal_width

iris_data.loc[(iris_data['class'] == 'Iris-setosa') &
              (iris_data['petal_width_cm'] == average_petal_width)]

# Again check for missing values
iris_data.loc[(iris_data['sepal_length_cm'].isnull()) |
              (iris_data['sepal_width_cm'].isnull()) |
              (iris_data['petal_length_cm'].isnull()) |
              (iris_data['petal_width_cm'].isnull())]

#### NOTE: Note: If you don't feel comfortable imputing your data, you can drop all rows with missing data 
#with the dropna() call:
#iris_data.dropna(inplace=True)

#After all this hard work, we don't want to repeat this process every time we work with the data set. 
#Let's save the tidied data file as a separate file and work directly with that data file from now on.

iris_data.to_csv('iris-data-clean.csv', index = False)

iris_data_clean = pd.read_csv('iris-data-clean.csv')
iris_data_clean.head()

# check if the dataframe has any missing values
iris_data_clean.isnull().values.any()

# Now, let's take a look at the scatterplot matrix now that we've tidied the data.
sb.pairplot(iris_data_clean, hue = 'class')

################################# Testing our data #######################################

assert 1 == 2


# We know that we should only have three classes
assert len(iris_data_clean['class'].unique()) == 3

# We know that sepal lengths for 'Iris-versicolor' should never be below 2.5 cm
assert iris_data_clean.loc[iris_data_clean['class'] == 'Iris-versicolor', 'sepal_length_cm'].min() >= 2.5

# We know that our data set should have no missing measurements
assert len(iris_data_clean.loc[(iris_data_clean['sepal_length_cm'].isnull()) |
                               (iris_data_clean['sepal_width_cm'].isnull()) |
                               (iris_data_clean['petal_length_cm'].isnull()) |
                               (iris_data_clean['petal_width_cm'].isnull())]) == 0


############################# Step 4: Exploratory analysis ##################################

# Exploratory analysis is the step where we start delving deeper into the data set beyond the outliers and errors. 
# We'll be looking to answer questions such as:
# How is my data distributed?
# Are there any correlations in my data?
# Are there any confounding factors that explain these correlations?

sb.pairplot(iris_data_clean)

sb.pairplot(iris_data_clean, hue='class')


plt.figure(figsize = (15, 15))

for column_index, column in enumerate(iris_data_clean.columns):
    if column == 'class':
        continue
    plt.subplot(2, 2, column_index + 1)
    sb.violinplot(x = 'class', y = column, data = iris_data_clean)


########################### Step 5: Classification #######################################
# it's time to make the next big step in our analysis: Splitting the data into training and 
# testing sets.

#A training set is a random subset of the data that we use to train our models.
#A testing set is a random subset of the data (mutually exclusive from the training set) that 
# we use to validate our models on unforseen data.

# Let's set up our data first.
iris_data_clean = pd.read_csv('iris-data-clean.csv')

# We're using all four measurements as inputs
# Note that scikit-learn expects each entry to be a list of values, e.g.,
# [ [val1, val2, val3],
#   [val1, val2, val3],
#   ... ]
# such that our input data set is represented as a list of lists

# We can extract the data in this format from pandas like this:
all_inputs = iris_data_clean[['sepal_length_cm', 'sepal_width_cm',
                             'petal_length_cm', 'petal_width_cm']].values

# Similarly, we can extract the classes
all_classes = iris_data_clean['class'].values

# Make sure that you don't mix up the order of the entries
# all_inputs[5] inputs should correspond to the class in all_classes[5]

# Here's what a subset of our inputs looks like:
all_inputs[:5]

# Now our data is ready to be split.

from sklearn.cross_validation import train_test_split

(training_inputs,
 testing_inputs,
 training_classes,
 testing_classes) = train_test_split(all_inputs, all_classes, train_size = 0.75, random_state = 1)


from sklearn.tree import DecisionTreeClassifier

# Create the classifier
decision_tree_classifier = DecisionTreeClassifier()

# Train the classifier on the training set
decision_tree_classifier.fit(training_inputs, training_classes)

# Validate the classifier on the testing set using classification accuracy
decision_tree_classifier.score(testing_inputs, testing_classes)


model_accuracies = []

for repetition in range(1000):
    (training_inputs,
     testing_inputs,
     training_classes,
     testing_classes) = train_test_split(all_inputs, all_classes, train_size = 0.75)
    
    decision_tree_classifier = DecisionTreeClassifier()
    decision_tree_classifier.fit(training_inputs, training_classes)
    classifier_accuracy = decision_tree_classifier.score(testing_inputs, testing_classes)
    model_accuracies.append(classifier_accuracy)
    
sb.distplot(model_accuracies)

########### Cross-validation ###############

import numpy as np
from sklearn.cross_validation import StratifiedKFold

def plot_cv(cv, n_samples):
    masks = []
    for train, test in cv:
        mask = np.zeros(n_samples, dtype = bool)
        mask[test] = 1
        masks.append(mask)
        
    plt.figure(figsize = (15, 15))
    plt.imshow(masks, interpolation = 'none')
    plt.ylabel('Fold')
    plt.xlabel('Row #')

plot_cv(StratifiedKFold(all_classes, n_folds = 10), len(all_classes))

# We can perform 10-fold cross-validation on our model with the following code:
from sklearn.cross_validation import cross_val_score
decision_tree_classifier = DecisionTreeClassifier()

# cross_val_score returns a list of the scores, which we can visualize
# to get a reasonable estimate of our classifier's performance
cv_scores = cross_val_score(decision_tree_classifier, all_inputs, all_classes, cv=10)
sb.distplot(cv_scores)
plt.title('Average score: {}'.format(np.mean(cv_scores)))

################### Parameter tuning ##########################
decision_tree_classifier = DecisionTreeClassifier(max_depth=1)

cv_scores = cross_val_score(decision_tree_classifier, all_inputs, all_classes, cv=10)
sb.distplot(cv_scores, kde=False)
plt.title('Average score: {}'.format(np.mean(cv_scores)))

### Let's tune our decision tree classifier. We'll stick to only two parameters for now, but it's possible to simultaneously explore dozens of parameters if we want.

from sklearn.grid_search import GridSearchCV
decision_tree_classifier = DecisionTreeClassifier()

parameter_grid = {'max_depth': [1, 2, 3, 4, 5],
                  'max_features': [1, 2, 3, 4]}

cross_validation = StratifiedKFold(all_classes, n_folds = 10)

grid_search = GridSearchCV(decision_tree_classifier,
                           param_grid = parameter_grid,
                           cv = cross_validation)

grid_search.fit(all_inputs, all_classes)
print('Best score: {}'.format(grid_search.best_score_))
print('Best parameters: {}'.format(grid_search.best_params_))

# Now let's visualize the grid search to see how the parameters interact.

grid_visualization = []

for grid_pair in grid_search.grid_scores_:
    grid_visualization.append(grid_pair.mean_validation_score)
    
grid_visualization = np.array(grid_visualization)
grid_visualization.shape = (5, 4)
sb.heatmap(grid_visualization, cmap = 'Blues')
plt.xticks(np.arange(4) + 0.5, grid_search.param_grid['max_features'])
plt.yticks(np.arange(5) + 0.5, grid_search.param_grid['max_depth'][::-1])
plt.xlabel('max_features')
plt.ylabel('max_depth')

# Let's go ahead and use a broad grid search to find the best settings for a handful of parameters.
decision_tree_classifier = DecisionTreeClassifier()

parameter_grid = {'criterion': ['gini', 'entropy'],
                  'splitter': ['best', 'random'],
                  'max_depth': [1, 2, 3, 4, 5],
                  'max_features': [1, 2, 3, 4]}

cross_validation = StratifiedKFold(all_classes, n_folds=10)

grid_search = GridSearchCV(decision_tree_classifier,
                           param_grid=parameter_grid,
                           cv=cross_validation)

grid_search.fit(all_inputs, all_classes)
print('Best score: {}'.format(grid_search.best_score_))
print('Best parameters: {}'.format(grid_search.best_params_))


# Now we can take the best classifier from the Grid Search and use that:
decision_tree_classifier = grid_search.best_estimator_
decision_tree_classifier

# We can even visualize the decision tree with GraphViz to see how it's making the classifications:
import sklearn.tree as tree
from sklearn.externals.six import StringIO

with open('iris_dtc.dot', 'w') as out_file:
    out_file = tree.export_graphviz(decision_tree_classifier, out_file=out_file)
    
# Alright! We finally have our demo classifier. Let's create some visuals of its performance so we have something to show our company's Head of Data.
dt_scores = cross_val_score(decision_tree_classifier, all_inputs, all_classes, cv=10)

sb.boxplot(dt_scores)
sb.stripplot(dt_scores, jitter=True, color='white')

################## Let's see if a Random Forest classifier works better here.

from sklearn.ensemble import RandomForestClassifier

random_forest_classifier = RandomForestClassifier()

parameter_grid = {'n_estimators': [5, 10, 25, 50],
                  'criterion': ['gini', 'entropy'],
                  'max_features': [1, 2, 3, 4],
                  'warm_start': [True, False]}

cross_validation = StratifiedKFold(all_classes, n_folds=10)

grid_search = GridSearchCV(random_forest_classifier,
                           param_grid=parameter_grid,
                           cv=cross_validation)

grid_search.fit(all_inputs, all_classes)
print('Best score: {}'.format(grid_search.best_score_))
print('Best parameters: {}'.format(grid_search.best_params_))

grid_search.best_estimator_


###### Now we can compare their performance:
random_forest_classifier = grid_search.best_estimator_

rf_df = pd.DataFrame({'accuracy': cross_val_score(random_forest_classifier, all_inputs, all_classes, cv=10),
                       'classifier': ['Random Forest'] * 10})
dt_df = pd.DataFrame({'accuracy': cross_val_score(decision_tree_classifier, all_inputs, all_classes, cv=10),
                      'classifier': ['Decision Tree'] * 10})
both_df = rf_df.append(dt_df)

sb.boxplot(x='classifier', y='accuracy', data=both_df)
sb.stripplot(x='classifier', y='accuracy', data=both_df, jitter=True, color='white')

# How about that? They both seem to perform about the same on this data set. This is probably 
#because of the limitations of our data set: We have only 4 features to make the classification, 
#and Random Forest classifiers excel when there's hundreds of possible features to look at. 
#In other words, there wasn't much room for improvement with this data set.


############################# Step 6: Reproducibility ###########################
%install_ext https://raw.githubusercontent.com/rasbt/watermark/master/watermark.py


#### Finally, let's extract the core of our work from Steps 1-5 and turn it into a single pipeline.
%matplotlib inline
import pandas as pd
import seaborn as sb
from sklearn.ensemble import RandomForestClassifier
from sklearn.cross_validation import train_test_split
from sklearn.cross_validation import cross_val_score

# We can jump directly to working with the clean data because we saved our cleaned data set
iris_data_clean = pd.read_csv('iris-data-clean.csv')

# Testing our data: Our analysis will stop here if any of these assertions are wrong

# We know that we should only have three classes
assert len(iris_data_clean['class'].unique()) == 3

# We know that sepal lengths for 'Iris-versicolor' should never be below 2.5 cm
assert iris_data_clean.loc[iris_data_clean['class'] == 'Iris-versicolor', 'sepal_length_cm'].min() >= 2.5

# We know that our data set should have no missing measurements
assert len(iris_data_clean.loc[(iris_data_clean['sepal_length_cm'].isnull()) |
                               (iris_data_clean['sepal_width_cm'].isnull()) |
                               (iris_data_clean['petal_length_cm'].isnull()) |
                               (iris_data_clean['petal_width_cm'].isnull())]) == 0

all_inputs = iris_data_clean[['sepal_length_cm', 'sepal_width_cm',
                             'petal_length_cm', 'petal_width_cm']].values

all_classes = iris_data_clean['class'].values

# This is the classifier that came out of Grid Search
random_forest_classifier = RandomForestClassifier(bootstrap=True, class_weight=None, criterion='gini',
                                max_depth=None, max_features=3, max_leaf_nodes=None,
                                min_samples_leaf=1, min_samples_split=2,
                                min_weight_fraction_leaf=0.0, n_estimators=5, n_jobs=1,
                                oob_score=False, random_state=None, verbose=0, warm_start=True)

# All that's left to do now is plot the cross-validation scores
rf_classifier_scores = cross_val_score(random_forest_classifier, all_inputs, all_classes, cv=10)
sb.boxplot(rf_classifier_scores)
sb.stripplot(rf_classifier_scores, jitter=True, color='white')

# ...and show some of the predictions from the classifier
(training_inputs,
 testing_inputs,
 training_classes,
 testing_classes) = train_test_split(all_inputs, all_classes, train_size=0.75)

random_forest_classifier.fit(training_inputs, training_classes)

for input_features, prediction, actual in zip(testing_inputs[:10],
                                              random_forest_classifier.predict(testing_inputs[:10]),
                                              testing_classes[:10]):
    print('{}\t-->\t{}\t(Actual: {})'.format(input_features, prediction, actual))







































