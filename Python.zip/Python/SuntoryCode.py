#Code to match the file column names
import pandas as pd
import os
import glob

fileNamelist = []
os.chdir('E:\My Data\Suntory\RawDataFiles')
for FileList in glob.glob('*.xlsx'):
    fileNamelist.append(FileList)
    fileName = FileList
#df1 = pd.read_csv('E:\My Data\Suntory\FileData.csv')
#df2 = pd.read_csv('E:\My Data\Suntory\FileDemo.csv')

frucorStandardFileFormat = pd.read_excel('E:\My Data\Suntory\StandardFileFormat\Frucor.xlsx', sheetname="Sheet1")
frucorDataFileRaw = pd.read_excel('E:\My Data\Suntory\RawDataFiles\Frucor Direct_Data format(FBL)-2016- - Copy.xlsx'
                                  , sheetname="Format(RM)", skiprows=4)
frucorDataFileRaw = frucorDataFileRaw.drop(frucorDataFileRaw.columns[[0,19,20]], axis = 1)
#print(frucorDataFileRaw.columns[[0,19,20]])
frucorDataFile = frucorDataFileRaw
frucorDataFileRaw.head(4)
df1_cols,df2_cols = list(frucorStandardFileFormat),list(frucorDataFile)
#df1_cols,df2_cols = list(df1),list(df2)
print(df1_cols)
print(df2_cols)
print(len(df1_cols) , len(df2_cols))

#lst = []
df = pd.DataFrame(columns=['Name of the Missing Columns'])
if len(df1_cols) != len(df2_cols):
    print('The columns headers are not similar in both the files','Data File' + str(len(df1_cols)), 
          'Standard File'+str(len(df2_cols)))
    if (frucorStandardFileFormat.equals(frucorDataFile)) != True:
            for col in frucorStandardFileFormat:
                if not col in frucorDataFileRaw:
                    print (col)
                    #lst.append(col)
                    df = df.append({'Name of the Missing Columns': col}, ignore_index=True)
                    #print(str(lst))
                    print(df)
                    df.to_csv("E:\My Data\Suntory\ErrorFiles\Fruco.csv", sep=',', index = False)
    else:
        print('The columns headers are similar in both the files')
else:
        print('The columns headers and counts are similar are similar in both the files')

      
import pandas as pd        
xyz = pd.read_excel('Malaysia Direct - 2016 Data format(LRSA).xlsx' , sheetname="Format(RM)", skiprows=3)
xyz = xyz.drop(xyz.columns[0,19,20,21,22,23,24,25,26], axis = 1) # [0,19,20]
xyz = xyz[xyz.Year == 2016]

xyz.to_csv("E:\\My Data\\Suntory\\OutPutFiles\\Test.csv", sep=',', index = False)
del xyz







