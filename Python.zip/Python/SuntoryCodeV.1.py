# -*- coding: utf-8 -*-
"""
Created on Fri Nov 24 12:43:00 2017

@author: Mohit.Vats
"""

#Code to match the file column names
#import numpy as np
import pandas as pd
import os
import glob



def ReadData( file_name, sheetname, columnstoskip, rowstoskip, columnstobedeletedList, country_flag):
    stdFileName = 'E:\\My Data\\Suntory\\StandardFileFormat\\' + country_flag + '.xlsx'
    standardFileFormat = pd.read_excel(stdFileName, sheetname = "Sheet1") # here sheetname is fixed
    dataFile = pd.read_excel(fileName , sheetname = sheetname, skiprows = rowstoskip)
#    print('In ReadData function for file '+file_name+ ' --Country Flag is-- '+country_flag)
#    print('In ReadData function for sheet '+sheetname)
#    print('In ReadData function for columnstoskip '+str(columnstoskip))
#    print('In ReadData function for rowstoskip '+str(rowstoskip))
#    print('In ReadData function for columnstobedeletedList '+str(columnstobedeletedList))
#    print('In ReadData function for file dimesnion is')
#    print(dataFile.shape)
#    print(dataFile.columns)
    
    dataFile = dataFile.drop(dataFile.columns[columnstobedeletedList], axis = 1) # [0,19,20]
#    dataFile = dataFile[dataFile.Year == 2016]
    df1_cols,df2_cols = list(standardFileFormat),list(dataFile)
    df = pd.DataFrame(columns=['Name of the Missing Columns'])
    print(len(df1_cols), len(df2_cols))
    if len(df1_cols) != len(df2_cols):
        print('The columns headers are not similar in both the files','Data File' + str(len(df1_cols)), 
              'Standard File'+str(len(df2_cols)))
        if (standardFileFormat.equals(dataFile)) != True:
                for col in standardFileFormat:
                    if not col in dataFile:
                        print (col)
                        df = df.append({'Name of the Missing Columns': col}, ignore_index=True)
                        print(df)
                        df.to_csv("E:\My Data\Suntory\ErrorFiles\Fruco.csv", sep=',', index = False)
        else:
            print('The columns header names are not similar in both the files')
                    
    else:
            print('The columns headers and counts are not similar are similar in both the files')
    return dataFile


def GetColIndexToDelete(fDRecords):
    
    fDRecords=fDRecords.reset_index()
    columnstobedeletedList = []
    print(columnstobedeletedList)
    noofcolumns = fDRecords.loc[0,"No of Columns"]
    colstoskip = fDRecords.loc[0,"Columns to skip"]
    colstodel = fDRecords.loc[0,"End Columns to be deleted"]
    print('In GetColIndexToDelete noofcolumns is'+ str(noofcolumns))
    print('In GetColIndexToDelete colstodel are'+ str(colstodel))
    print('In GetColIndexToDelete colstoskip are'+ str(colstoskip))
    columnsToSkipIndex = []
    if colstoskip > 0:
        print('colstoskip'+str(colstoskip))
        for c in range(0, colstoskip):
            columnsToSkipIndex.append(c)
        
    if colstodel > 0:
        print('colstodel'+ str(colstodel))
        if colstoskip > 0:
            incrementalValue = 1
        else:
            incrementalValue = 0
        for cd in range(0, colstodel):
            columnsToSkipIndex.append(noofcolumns + incrementalValue)
            incrementalValue = incrementalValue + 1

    columnstobedeletedList = columnsToSkipIndex[:]
    print('columnsToSkipIndex--columnstobedeletedList')
    print(columnsToSkipIndex)
    print(columnstobedeletedList)
    return columnstobedeletedList



columnstobedeletedListParam = []
fileDictionary = pd.read_excel('E:\My Data\Suntory\StandardFileFormat\FileDictionary.xlsx', sheetname="Sheet1")
counter = 1
os.chdir('E:\My Data\Suntory\RawDataFiles')
for FileList in glob.glob('*.xlsx'):
    
    fileName = FileList
#    print('File name ' + str(counter) + ' is '+ fileName)
    strarr = fileName.split(sep = ' ')
    country = strarr[0]
    country_flag = ''
    b = False
    if fileName.find("Direct") > 0 :
        print("Data Contains Direct And Country Is--- "+country)
        if country == 'Australia':
            country_flag = country
        elif country == 'SBFE':
            country_flag = country
        else:
            country_flag = country + " Direct"
    elif fileName.find("Indirect") > 0 :
        print("Data Contains Indirect In ElseIf Section")
        country_flag = country + " InDirect"
    else:
        print("Data Contains Indirect in Else Section")
    
    # get record from dictionary
    fileDicRecords = fileDictionary[fileDictionary.Country == country_flag]
    print(fileDicRecords)
    noofrowsForCountry = fileDicRecords.shape[0]
    columnstobedeletedList = []
    df_1 = pd.DataFrame()
    if noofrowsForCountry > 1:
        print("In Multiple File Seets If")
        #loop for each
        for n in range(noofrowsForCountry):
            print("------------for n in range(noofrowsForCountry)-----------")

            lst=fileDicRecords.columns
            lst1=[]
            lst1.append(fileDicRecords.iloc[n])
            df=pd.DataFrame(data=lst1,columns=lst)
            columnstobedeletedListParam =  GetColIndexToDelete(df)
            if country_flag == 'Malaysia Direct':
                print('----AAAA----')
                print(columnstobedeletedListParam)
            #del df
            # file_name, sheetname, columnstoskip, rowstoskip, columnstobedeleted
            temp_df = ReadData(fileName, fileDicRecords.iloc[n]["Sheet Name"]
                            , fileDicRecords.iloc[n]["Columns to skip"]
                            , fileDicRecords.iloc[n]["Rows to skip"]
                            , columnstobedeletedListParam, country_flag)
            temp_df.insert(loc=0, column = 'Sheet Name', value = fileDicRecords.iloc[n]["Sheet Name"])
            #fileDictionary.iloc[1]["Sheet Name"]
            #df_1 = pd.DataFrame(columns=list(temp_df.columns))
            df_1 = df_1.append(temp_df,ignore_index=True)
            #df_1 = df_1.append(temp_df)
            
    else:
        print("In Single File Final Else")
        columnstobedeletedListParam =  GetColIndexToDelete(fileDicRecords)
        temp_df = ReadData(fileName, fileDicRecords.iloc[0]["Sheet Name"]
                            , fileDicRecords.iloc[0]["Columns to skip"]
                            , fileDicRecords.iloc[0]["Rows to skip"]
                            , columnstobedeletedListParam, country_flag)
        df_1 = pd.DataFrame(columns=list(temp_df.columns))
        df_1 = df_1.append(temp_df)
    
    writer = pd.ExcelWriter("E:\\My Data\\Suntory\\OutPutFiles\\Output_"+country_flag+".xlsx", engine='xlsxwriter')
    # Write each dataframe to a different worksheet.
    df_1.to_excel(writer,index = False)
    #df_1.to_csv("E:\\My Data\\Suntory\\OutPutFiles\\Output_"+country_flag+".csv", sep=',', index = False)
    #del temp_df,df_1
    counter = counter + 1
