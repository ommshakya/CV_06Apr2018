# -*- coding: utf-8 -*-
"""
Created on Thu Nov 30 17:22:41 2017

@author: Mohit.Vats
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Nov 24 12:43:00 2017

@author: Mohit.Vats
"""

#Code to match the file column names
#import numpy as np
import pandas as pd
import os
import glob



def ReadData(file_name, sheetname, columnstoskip, rowstoskip, columnstobedeletedList, country_flag):
    stdFileName = 'E:\\My Data\\Suntory\\StandardFileFormat\\' + country_flag + '.xlsx'
    standardFileFormat = pd.read_excel(stdFileName, sheetname = "Sheet1") # here sheetname is fixed
    dataFile = pd.read_excel(fileName , sheetname = sheetname, skiprows = rowstoskip)
    dataFile = dataFile.drop(dataFile.columns[columnstobedeletedList], axis = 1) # [0,19,20]
#    dataFile = dataFile[dataFile.Year == 2016]
    df1_cols,df2_cols = list(standardFileFormat),list(dataFile)
    df = pd.DataFrame(columns=['Name of the Missing Columns'])
    x = 1
    print(df1_cols == df2_cols)
    print('AAAA'+ str(x))
    if len(df1_cols) != len(df2_cols):
        print('The columns headers count are not similar in both the files','Data File' + str(len(df1_cols)), 
              'Standard File'+str(len(df2_cols)))
        if (standardFileFormat.equals(dataFile)) != True:
                x = 0
                print('BBBB'+ str(x))
                for col in standardFileFormat:
                    if not col in dataFile:
                        df = df.append({'Name of the Missing Columns': col}, ignore_index=True)
                        df.to_csv("E:\\My Data\\Suntory\\ErrorFiles\\"+ country_flag +".csv", sep=',', index = False)
    
    elif (len(df1_cols) == len(df2_cols) and (df1_cols == df2_cols) == False):
        print(df1_cols == df2_cols)
        for col in standardFileFormat:
                    x = 0
                    print('CCCC'+ str(x))
                    if not col in dataFile:
                        df = df.append({'Name of the Missing Columns': col}, ignore_index=True)
                        df.to_csv("E:\\My Data\\Suntory\\ErrorFiles\\"+ country_flag +".csv", sep=',', index = False)
        
    else:
        x = 1
        print('The columns headers and counts are similar are similar in both the files')
        print('DDDD'+ str(x))
#    if x == 1:
#        return dataFile,x
#    else:
#        return None,x
#    print(dataFile)
    print(x)
    return dataFile,x


def GetColIndexToDelete(fDRecords):
    
    fDRecords=fDRecords.reset_index()
    columnstobedeletedList = []
    noofcolumns = fDRecords.loc[0,"No of Columns"]
    colstoskip = fDRecords.loc[0,"Columns to skip"]
    colstodel = fDRecords.loc[0,"End Columns to be deleted"]
    columnsToSkipIndex = []
    if colstoskip > 0:
        for c in range(0, colstoskip):
            columnsToSkipIndex.append(c)
        
    if colstodel > 0:
        if colstoskip > 0:
            incrementalValue = 1
        else:
            incrementalValue = 0
        for cd in range(0, colstodel):
            columnsToSkipIndex.append(noofcolumns + incrementalValue)
            incrementalValue = incrementalValue + 1

    columnstobedeletedList = columnsToSkipIndex[:]
    return columnstobedeletedList



columnstobedeletedListParam = []
fileDictionary = pd.read_excel('E:\My Data\Suntory\StandardFileFormat\FileDictionary.xlsx', sheetname="Sheet1")
counter = 1
os.chdir('E:\My Data\Suntory\RawDataFiles')
for FileList in glob.glob('*.xlsx'):
    
    fileName = FileList
    strarr = fileName.split(sep = ' ')
    country = strarr[0]
    country_flag = ''
    b = False
    if fileName.find("Direct") > 0 :
        if country == 'Australia':
            country_flag = country
        elif country == 'SBFE':
            country_flag = country
        else:
            country_flag = country + " Direct"
    elif fileName.find("Indirect") > 0 :
        print("Data Contains Indirect In ElseIf Section")
        country_flag = country + " InDirect"
    else:
        print("Data Contains Indirect in Else Section")
    
    
    # get record from dictionary
    fileDicRecords = fileDictionary[fileDictionary.Country == country_flag]
    noofrowsForCountry = fileDicRecords.shape[0]
    columnstobedeletedList = []
    df_1 = pd.DataFrame()
    if noofrowsForCountry > 1:
    #loop for each
        for n in range(noofrowsForCountry):
            lst=fileDicRecords.columns
            lst1=[]
            lst1.append(fileDicRecords.iloc[n])
            df=pd.DataFrame(data=lst1,columns=lst)
            columnstobedeletedListParam =  GetColIndexToDelete(df)
            if country_flag == 'Malaysia Direct':
            
                temp_df = ReadData(fileName, fileDicRecords.iloc[n]["Sheet Name"]
                            , fileDicRecords.iloc[n]["Columns to skip"]
                            , fileDicRecords.iloc[n]["Rows to skip"]
                            , columnstobedeletedListParam, country_flag)
                temp_df.insert(loc=0, column = 'Sheet Name', value = fileDicRecords.iloc[n]["Sheet Name"])
            df_1 = df_1.append(temp_df,ignore_index=True)
            
    else:
        columnstobedeletedListParam =  GetColIndexToDelete(fileDicRecords)
        temp_df,z = ReadData(fileName, fileDicRecords.iloc[0]["Sheet Name"]
                            , fileDicRecords.iloc[0]["Columns to skip"]
                            , fileDicRecords.iloc[0]["Rows to skip"]
                            , columnstobedeletedListParam, country_flag)
        if z == 1:
            print('Z isissi '+str(z))
            df_1 = pd.DataFrame(columns=list(temp_df.columns))
            df_1 = df_1.append(temp_df)
    
    writer = pd.ExcelWriter("E:\\My Data\\Suntory\\OutPutFiles\\Output_"+country_flag+".xlsx", engine='xlsxwriter')
    # Write each dataframe to a different worksheet.
    df_1.to_excel(writer,index = False)
    #df_1.to_csv("E:\\My Data\\Suntory\\OutPutFiles\\Output_"+country_flag+".csv", sep=',', index = False)
    #del temp_df,df_1
    counter = counter + 1
