# -*- coding: utf-8 -*-
"""
Created on Fri Nov 24 12:43:00 2017

@author: Mohit.Vats
"""

#Code to match the file column names
#import numpy as np
import pandas as pd
import os
import glob

##### Function to read the raw files and do all the manipulation and standardization activities#####
def ReadData( file_name, sheetname, columnstoskip, rowstoskip, columnstobedeletedList, country_flag, countryName):
    
    ##### Extracting standard column names from the Standard File Format Folder #####
    stdFileColumnNames = 'E:\\My Data\\Suntory\\MainFilesCreation\\StandardFileFormat\\' + country_flag + '.xlsx'
    standardFileFormat = pd.read_excel(stdFileColumnNames, sheetname = "Sheet1")
    
    ##### Extracting conversion rates for the currency conversion #####
    conversionFileFormat = pd.read_excel('E:\\My Data\\Suntory\\MainFilesCreation\\StandardFileFormat\\List of Required Currency Conersion Rates - コピー.xlsx', 
                                         sheetname = "cover",skiprows=2) # here sheetname is fixed
    conversionFileFormat = conversionFileFormat.iloc[:,[2,3]]
    conversionFileFormat.columns = ["Currency","Currency USD"]
    
    ##### Extracting data from the Raw Files Folder for processing and standardsation #####
    dataFile = pd.read_excel(fileName , sheetname = sheetname, skiprows = rowstoskip)
    
    if country_flag == 'Japan Direct PM' and sheetname == 'PM':
        dataFile = dataFile.iloc[:,0:31]
    elif country_flag == 'Japan Direct RM' and sheetname == 'RM':
        dataFile = dataFile.iloc[:,[1,2,3,4,5,6,7,8,9,10,11,12,27,28,34,35,36,41,43]]
    else:
        dataFile = dataFile.drop(dataFile.columns[columnstobedeletedList], axis = 1) # [0,19,20]
        if country_flag == 'Indonesia Indirect':
            dataFile = dataFile.drop(dataFile.columns[[1,14,15]], axis = 1)
        elif country_flag == 'Malaysia Indirect':
            dataFile = dataFile.drop(dataFile.columns[[1]], axis = 1)
#    dataFile = dataFile[dataFile.Year == 2016]
    
    ##### Applying the standardized colum names to the data set #####
    df1_cols = list(standardFileFormat)
    dataFile.columns = df1_cols
    
    ##### Adding additional columns like CountryName and SpendType #####
    if country_flag != 'Japan Direct PM':
        dataFile.insert(1, 'Country', countryName)
    dataFile.insert(2, 'Spend Type', dataFile.apply (lambda row: label_race (row),axis=1))
    
    ##### Applying Data Conversion rules and values as per the data extracted above #####
    dataConversion = pd.merge(dataFile, conversionFileFormat, how='left', on=['Currency'])
    dataFile['Currency USD'] = dataConversion['Currency USD']
    del dataConversion
    dataFile['Converted Value In USD'] = dataFile['Spend LCC'] * dataFile['Currency USD']
    
    return dataFile


##### Function to delete the irrelevant columns and rows #####
def GetColIndexToDelete(fDRecords):
    
    fDRecords=fDRecords.reset_index()
    columnstobedeletedList = []
#    print(columnstobedeletedList)
    noofcolumns = fDRecords.loc[0,"No of Columns"]
    colstoskip = fDRecords.loc[0,"Columns to skip"]
    colstodel = fDRecords.loc[0,"End Columns to be deleted"]
    columnsToSkipIndex = []
#    print('colstoskip')
#    print(colstoskip)
    if colstoskip > 0:
        for c in range(0, colstoskip):
            columnsToSkipIndex.append(c)
        
    if colstodel > 0:
        if colstoskip > 0:
            incrementalValue = 1
        else:
            incrementalValue = 0
        for cd in range(0, colstodel):
            columnsToSkipIndex.append(noofcolumns + incrementalValue)
            incrementalValue = incrementalValue + 1

    columnstobedeletedList = columnsToSkipIndex[:]
    return columnstobedeletedList

##### Function to create the Spend Type column based on the "Taxonomy L1" column #####
def label_race (row):
   if row['Taxonomy L1'] == 'RM' or row['Taxonomy L1'] == 'PM':
      return 'Direct'
   if row['Taxonomy L1'] == 'InterCompany' :
      return 'InterCompany'
   return 'Indirect'



columnstobedeletedListParam = []

##### Read the File Dictionary for the file formats which have been standardized #####
fileDictionary = pd.read_excel('E:\My Data\Suntory\MainFilesCreation\StandardFileFormat\FileDictionary.xlsx', sheetname="Sheet1")

counter = 1

##### Code to read the raw files in an incremental manner #####
os.chdir('E:\My Data\Suntory\MainFilesCreation\RawDataFiles')
for FileList in glob.glob('*.xlsx'):
    
    fileName = FileList
#    print('File name ' + str(counter) + ' is '+ fileName)
    strarr = fileName.split(sep = ' ')
    country = strarr[0]
    spendType = strarr[1]
    additionalFlag = strarr[2]
    country_flag = ''
    b = False
    if spendType == "Direct":
#        print("Data Contains Direct And Country Is--- "+country)
        spendType = 'Direct'
        if country == 'Australia' or country == 'SBFE':
            country_flag = country
        elif country == 'Japan':
            country_flag = country + " Direct " + additionalFlag
        else:
            country_flag = country + " Direct"
    elif spendType == "Indirect":
        spendType = 'Indirect'
#        print("Data Contains Indirect In ElseIf Section")
        country_flag = country + " Indirect"
    else:
        country_flag = country
#        print("Data Contains Indirect in Else Section")
    
    # get record from dictionary
    fileDicRecords = fileDictionary[fileDictionary.Country == country_flag]
    noofrowsForCountry = fileDicRecords.shape[0]
    columnstobedeletedList = []
    df_1 = pd.DataFrame()
    
    ##### Function to create the Spend Type column based on the "Taxonomy L1" column #####
    if noofrowsForCountry > 1:
        #loop for each
        for n in range(noofrowsForCountry):
            lst=fileDicRecords.columns
            lst1=[]
            lst1.append(fileDicRecords.iloc[n])
            df=pd.DataFrame(data=lst1,columns=lst)
            
            ##### Function to delete the irrelevant columns and rows invoked here #####
            columnstobedeletedListParam =  GetColIndexToDelete(df)
            
            ##### Function to read the raw files and do all the manipulation and standardization activities invoked here #####
            # file_name, sheetname, columnstoskip, rowstoskip, columnstobedeleted
            temp_df = ReadData(fileName, fileDicRecords.iloc[n]["Sheet Name"]
                            , fileDicRecords.iloc[n]["Columns to skip"]
                            , fileDicRecords.iloc[n]["Rows to skip"]
                            , columnstobedeletedListParam, country_flag, country)
            temp_df.insert(loc=2, column = 'Sheet Name', value = fileDicRecords.iloc[n]["Sheet Name"])
            df_1 = df_1.append(temp_df,ignore_index=True)
            
    else:
        ##### Function to delete the irrelevant columns and rows invoked here #####
        columnstobedeletedListParam =  GetColIndexToDelete(fileDicRecords)
        
        ##### Function to read the raw files and do all the manipulation and standardization activities invoked here #####
        temp_df = ReadData(fileName, fileDicRecords.iloc[0]["Sheet Name"]
                            , fileDicRecords.iloc[0]["Columns to skip"]
                            , fileDicRecords.iloc[0]["Rows to skip"]
                            , columnstobedeletedListParam, country_flag, country)
        df_1 = pd.DataFrame(columns=list(temp_df.columns))
        df_1 = df_1.append(temp_df)
    
    ##### Write the file to the destination folder for all the Business Units' dynamically #####
    df_1.to_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\"+country_flag+".csv", sep=',', index = False, encoding='utf-8-sig')
    counter = counter + 1
    
#dfAustralia = pd.read_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\Australia.csv",encoding='cp1252')
#dfFrucorDirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Frucor Direct.csv",encoding='cp1252')
#dfFrucorIndirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Frucor Indirect.csv",encoding='cp1252')
#dfIndonesiaDirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Indonesia Direct.csv",encoding='cp1252')
#dfIndonesiaIndirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Indonesia Indirect.csv",encoding='cp1252')
#dfJapanDirectPM = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Japan Direct PM.csv",encoding='utf-8-sig')
#dfJapanDirectRM = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Japan Direct PM.csv",encoding='utf-8-sig')
#dfMalaysiaDirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Malaysia Direct.csv",encoding='cp1252')
#dfMalaysiaIndirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Malaysia Indirect.csv",encoding='cp1252')
#dfSBFE = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\SBFE.csv",encoding='cp1252')
#dfVietnamDirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Vietnam Direct.csv",encoding='cp1252')
#dfVietnamIndirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Vietnam Indirect.csv",encoding='cp1252')
#
#
#dfConsolidated = pd.concat([dfAustralia, dfFrucorDirect, dfFrucorIndirect, dfIndonesiaDirect, dfIndonesiaIndirect, dfJapanDirectPM, dfJapanDirectRM, 
#                            dfMalaysiaDirect, dfMalaysiaIndirect, dfSBFE, dfVietnamDirect, dfVietnamIndirect], axis = 0, ignore_index = True)
#
#dfConsolidated.to_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\Consolidated.csv", sep=',', index = False)
    
    
    