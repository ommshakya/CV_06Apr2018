# -*- coding: utf-8 -*-
"""
Created on Wed Nov 22 11:49:47 2017

@author: Mohit.Vats
"""
import pandas as pd

for line in open('E:\My Data\Python\A.txt'):
    print(line.upper())

for line1 in open('E:\My Data\Python\A.txt').readlines():
    print(line1.upper())

dataList = [{'a': 1}, {'b': 3}, {'c': 5}]
for index in range(len(dataList)):
    for key in dataList[index]:
        print(key)
        print(dataList[index][key])

print(len(dataList))
print(dataList[2])


df = pd.read_csv('E:\My Data\Suntory\Files\FileSplit.csv')
for i, g in df.groupby('Column1'):
    g.to_csv('E:\My Data\Suntory\Files\{}.csv'.format(i), header=True, index_label='Index',index = True)

df = pd.read_csv('E:\My Data\Suntory\Files\TSC - Beam Suntory - H2 2015-H2 2016 Spend - May 22.xlsx')
for i, g in df.groupby('Column1'):
    g.to_csv('E:\My Data\Suntory\Files\{}.csv'.format(i), header=True, index_label=True,index = True)
        
print(df)


#df = pd.read_csv('E:\My Data\Suntory\Files\TSC - Beam Suntory - H2 2015-H2 2016 Spend - May 22.xlsx')
df = pd.read_excel('E:\My Data\Suntory\Files\TSC - BSI - Q1 2017 - June 22, 2017.xlsx', 'Main File', index_col=None)
#data_xls.to_csv('your_csv.csv', encoding='utf-8')
for i, g in df.groupby('Month (Period)'):
    #g.to_csv('E:\My Data\Suntory\Files\{}.csv'.format(i), header=True, index_label=False,index = False)
    g.to_csv('E:\My Data\Suntory\Files\Beam Suntory\May 22\{}.csv'.format(i), header=True, index_label=False,index = False, encoding='utf-8')

print(df)
del df

#Code to match the file column names
import csv
with open("E:\My Data\Suntory\FileData.csv", "r") as f:
    reader = csv.reader(f)
    i = [next(reader)]

    print(i)

with open("E:\My Data\Suntory\FileDemo.csv", "r") as f:
    reader = csv.reader(f)
    i1 = [next(reader)]

    if(i==i1):
        print('Data Columns Matched')
    else:
        print('Data Columns Not Matched')
    
    print(i==i1)
    
    for i in zip(i,i1):
        print(i)
  
    print([i for i, i1 in zip(i, i1) if i == i1])
    
    
df1 = pd.read_csv('E:\My Data\Suntory\FileData.csv')
df2 = pd.read_csv('E:\My Data\Suntory\FileDemo.csv')   
df1_cols,df2_cols = list(df1),list(df2)
lst = []
df = pd.DataFrame(columns=['Name'])
#df3 = pd.DataFrame(columns=('S.No.','Name'))
#print(df3)
#cmp(df1_cols,df2_cols)
#print(df2.columns.intersection(df1.columns))
#print(df2.columns.difference(df1.columns))
#print(df1_cols)
#print(df2_cols)
#print(df2.columns)
if len(df1_cols) != len(df2_cols):
    print (len(df1_cols), len(df2_cols))
    print(df1.equals(df2))
if (df1.equals(df2)) != True:
        for col in df1_cols:
            if not col in df2_cols:
                print (col)
        #print('\n')
        for col in df2_cols:
            
            if not col in df1_cols:
                print (col)
                lst = lst.append(col)
                df = df.append({'Name': col}, ignore_index=True)
                print(str(lst))
else:
    print('The columns headers are similar in both the files')

import os
import glob
fileNamelist = []
os.chdir('E:\My Data\Suntory\RawDataFiles')
for FileList in glob.glob('*.xlsx'):
    fileNamelist.append(FileList)
    print(fileNamelist[0:3])
    print(FileList)
    
    