#D:\z.Oms\Learn.R\Dplyr
setwd("D:\\z.Oms\\Learn.R\\Dplyr")
getwd()

# read the csv file
mydata = read.csv("sampledata.csv")
head(mydata)
str(mydata)

library(dplyr)

# Example 1 : Selecting Random N Rows
sample_n(mydata, 3)

# Example 2 : Selecting Random Fraction of Rows
sample_frac(mydata, 0.01)

# Example 3 : Remove Duplicate Rows based on all the variables (Complete Row)
x1 = distinct(mydata)
x1

# Example 4 : Remove Duplicate Rows based on a variable
x2 = distinct(mydata, Index, .keep_all = T)
x2

# Example 5 : Remove Duplicates Rows based on multiple variables
x2 = distinct(mydata, Index, Y2010, .keep_all = T)
x2

# Example 6 : Selecting Variables (or Columns)
# Suppose you are asked to select only a few variables. The code below selects variables "Index", columns from "State" to "Y2008".

select(mydata, Index, State:Y2008)

# Example 7 : Dropping Variables
mydata = select(mydata,-Index, -State)
#OR
mydata = select(mydata,-c(Index, State))

# Example 8 : Selecting or Dropping Variables starts with 'Y'
mydata3 = select(mydata, start("y"))

# Example 9 : Selecting Variables contain 'Y' in their names
mydata4 = select(mydata, contains("y"))
head(mydata4)

#   Example 10 : Reorder Variables
mydata5 = select(mydata, State, everything())
head(mydata5)

# Example 11 : Rename Variables
# In the following code, we are renaming 'Index' variable to 'Index1'.
mydata6 = rename(mydata, Index1 = Index)

# Example 12 : Filter Rows
mydata7 = filter(mydata, Index == "A")

# Example 13 : Multiple Selection Criteria'
#The %in% operator can be used to select m
mydata7 = filter(mydata, Index %in% c("A", "c"))


# Example 14 : 'AND' Condition in Selection Criteria
#Suppose you need to apply 'AND' condition. In this case, we are picking data for 'A' and 'C' in the column 'Index' and income greater than 1.3 million in Year 2002.

mydata8 = filter(mydata, Index %in% c("A", "c") & Y2002 >= 1300000)

# Example 15 : 'OR' Condition in Selection Criteria
# The 'I' denotes OR in the logical condition. It means any of the two conditions.
mydata8 = filter(mydata, Index %in% c("A", "c") | Y2002 >= 1300000)

# Example 16 : NOT Condition
mydata10 = filter(mydata, !Index %in% c("A", "C"))

# Example 17 : CONTAINS Condition

#The grepl function is used to search for pattern matching. In the following code, we are looking for records wherein column state contains 'Ar' in their name.

mydata10 = filter(mydata, grepl("Ar", State))

# Example 18 : Summarize selected variables
# In the example below, we are calculating mean and median for the variable Y2015.
summarise(mydata, Y2015_mean = mean(Y2015), Y2015_med = median(Y2015))

# Example 19 : Summarize Multiple Variables
# In the following example, we are calculating number of records, mean and median for variables Y2005 and Y2006. The summarise_at function allows us to select multiple variables by their names.
summarize_at(mydata, vars(Y2005, Y2006), funs(n(), mean, median))

# Example 20 : Summarize with Custom Functions
# We can also use custom functions in the summarise function. In this case, we are computing the number of records, number of missing values, mean and median for variables Y2011 and Y2012. The dot (.) denotes each variables specified in the second argument of the function.

summarise_at(mydata, vars(Y2011, Y2012),
             funs(n(), missing = sum(is.na(.)), mean(., na.rm = TRUE), median(.,na.rm = TRUE)))

# Example 21 : Summarize all Numeric Variables
# The summarise_if function allows you to summarise conditionally.
summarise_if(mydata, is.numeric, funs(n(), mean, median))

# Example 22 : Summarize Factor Variable
# We are checking the number of levels/categories and count of missing observations in a categorical (factor) variable.

summarise_all(mydata["Index"], funs(nlevels(.), sum(is.na(.))))

# Example 23 : Sort Data by Multiple Variables
# The default sorting order of arrange() function is ascending. In this example, we are sorting data by multiple variables.
arrange(mydata, Index, Y2011)
# Suppose you need to sort one variable by descending order and other variable by ascending oder.
arrange(mydata, desc(Index), Y2011)


# Example 24 : Summarise Data by Categorical Variable
# We are calculating count and mean of variables Y2011 and Y2012 by variable Index.
t = mydata %>% group_by(Index) %>% summarise_at(vars(Y2011:Y2015), funs(n(), mean(., na.rm = TRUE)))

# Example 25 : Filter Data within a Categorical Variable
# Suppose you need to pull top 2 rows from 'A', 'C' and 'I' categories of variable Index. 
t = mydata %>% filter(Index %in% c("A", "C","I")) %>% group_by(Index) %>%
  do(head( . , 2))
t

# Example 26 : Selecting 3rd Maximum Value by Categorical Variable
# We are calculating third maximum value of variable Y2015 by variable Index. The following code first selects only two variables Index and Y2015. Then it filters the variable Index with 'A', 'C' and 'I' and then it groups the same variable and sorts the variable Y2015 in descending order. At last, it selects the third row.

t = mydata %>% select(Index, Y2015) %>%
  filter(Index %in% c("A","C","I")) %>%
  group_by(Index) %>%
  do(arrange(., desc(Y2015))) %>% slice(3)
t







