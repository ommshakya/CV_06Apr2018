getwd()
dirpath = "D:/z.Oms/Learn.R/R. Good. Descriptive Statistics"
dir.create(dirpath)
setwd(dirpath)
getwd()

# Download file 'students.csv' from the internet.
download.file("http://dss.princeton.edu/training/students.xls",
              "downloaded_students.xls",
              method = "auto",
              quiet = FALSE,
              mode = "wb",
              cacheOK = TRUE)

# Needed packages
#specify the packages of interest
packages = c("foreign","car", "Hmisc", "reshape2")

package.check <- lapply(packages, FUN = function(x) {
  if (!require(x, character.only = TRUE)) {
    install.packages(x, dependencies = TRUE)
    library(x, character.only = TRUE)
  }
})

#verify they are loaded
search()