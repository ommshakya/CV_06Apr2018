# Check and set the working directory
getwd()
setwd("D:\\z.Oms\\Learn.R\\Case Study - Predictive_Analytics_Methdology_Using_R_v1")
getwd()

# Read the data.csv file into memory
data<-read.csv("data.csv")
head(data)

attach(data)

mean(TOTALM)
median(TOTALM)

range(TOTALM)
var(TOTALM)
sd(TOTALM)

# mean,median,25th and 75th quartiles,min,max
summary(TOTALM)

# min,lower-hinge, median,upper-hinge,max
fivenum(TOTALM)

summary(data)
table(is.na(TOTALM))

nrow(data)
sum(is.na(data))

newdata = na.omit(data)
nrow(newdata)
sum(is.na(newdata))

mean(data$TOTALM)
mean(as.numeric(data$TOTALM), na.rm = T)

#Replacing missing values using various statistical measures
data$TOTALM[is.na(data$TOTALM)] <- round(mean(data$TOTALM, na.rm = TRUE))

data$TOTALM[is.na(data$TOTALM)] <- median(data$TOTALM, na.rm = TRUE)

mean(data$TOTALM)

summary(data$TOTALM)

#check outliers in data
hist(data$TOTALM)

# Handle outlier
m <- mean(TOTALM, na.rm = TRUE) # Mean of the variable X21
sd <- sd(TOTALM, na.rm = TRUE) #StdDev of the variable X21
ul <- m + (2*sd) # Upper limit is calculated as Mean+2(StdDev)
ll <- m - (2*sd) # Lower limit is calculated as Mean-2(StdDev)
# Capping values based on Mean & 2(StdDev)measures
TOTALM<-as.numeric(
  ifelse(data$TOTALM <= ll,ll, ifelse(data$TOTALM >=ul,ul, TOTALM))
  )
hist(TOTALM)

#Binning Values
#Sometimes it is very difficult to explain the numeric values. Hence binning such variables can add some business sense and also very easy to explore data.
summary(AGEC)
age<-as.factor(
  ifelse(AGEC<=4.75,'Young',
         ifelse(AGEC<=16.5,'Mature','Old')))
summary(age)
counts <- table(VILLAGE,age)
counts #Table View


#Stacked bar plot
barplot(counts,
         main="Stacked Bar Plot",
         xlab="Age", ylab="Frequency",
         col=c("yellow","green"),
         legend=rownames(counts))

#Grouped bar plot
barplot(counts,
         main="Grouped Bar Plot",
         xlab="Age", ylab="Frequency",
         col=c("yellow", "green"),
         legend=rownames(counts), beside=TRUE)

#Breaking Data into Training and Test Sample

nrow(data) #No Of observations in complete data
d = sort(sample(nrow(data), nrow(data)*.8))
#select training sample
train <- data[d,]
test <- data[-d,]
nrow(train) #No Of observations in training data
nrow(test) #No Of observations in testing data

str(train)
#Variable Reduction
#Collinearity Measure
TOTALM = TOTALM
#fit<- glm(TOTALM~COWNO+VILLAGE+LOCATION+AGEC+QTYM+QTYE,data=train, family=binomial(logit))
fit<- glm(TOTALM~1,data=train, family=binomial(logit))
vif(fit)
