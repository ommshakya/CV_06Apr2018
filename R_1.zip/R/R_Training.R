# Getting Started with Basics of R programming

# R is a programming language and environment for statistical computing and graphics
# R is a open software and can be downloaded from cran.r-project.org or rstudio.com

# Shortcuts -
# CTRL + SHIFT + A - Format the Code
# CTRL + SHIFT + C - Comment/Uncomment the code
# CTRL + ENTER or CTRL + R - Run the code
# CTRL + L - Clear Console

# Check the current working directory
getwd()

# Set the working directory
setwd("C:\\Users\\shubham.rohatgi\\Desktop\\R_training\\R_files")

# setwd("C:/Users/shubham.rohatgi/Desktop/R_training/R_files")

# Basic Calculations
x = 2
y = 3
z = x * y
print(x * y)

z = x / y

print(z)

pi
print(2 * pi)
cat("The zero occurs at", 2 * pi, "r", "\n")
ls()
.z = 5

ls(all.names = TRUE) # lists the names of objects in the work space (name starining with period (.) are not listed so use this argument)

ls.str()
typeof(x)

# Create a vector
Vec = c(1, 2, 3, 4, 5)
Vec

Mean_Vec = mean(Vec)
Mean_Vec

Max_Vec = max(Vec)
Max_Vec

Min_Vec = min(Vec)
Min_Vec

Vec_Squares = Vec ** 2
Vec_Squares
Vec

Vec1 = c(0, 2, 4,6,8,9)
Vec1


Vec_multi_result = Vec1 * Vec
Vec_multi_result

# Subsetting
Vec1[1:6] # Check

# Sort a vector 
Vec2 = sort(Vec1, decreasing = TRUE)
Vec2

# Frequency

Companies = c("TSC", "TCS", "PWC", "TSC")
tab = table(Companies)

typeof(tab) # check

# Missing values

Miss_vec = c(1, 2, 3, NA, 5)
sum(Miss_vec) # R uses 'NA'  for missing values and any calcukation on 'NA' will result in 'NA'
sum(Miss_vec, na.rm = TRUE) # na.rm removes the missing value and then calculates the sum

# Generate sequence

1:10

seq(1, 10, 2) # Starting from, TIll ,  By

x = 3
rep(x, 5)

sample(10:20, 8, replace = TRUE) # From, To, How many, with/without replacement

# Help

help(lm)
?lm

args(lm) # arguments of the searched function
example(lm) # example of the searched function

# Matrices

x = c(1, 2,3)
y = c(2,3,5)

z = cbind(x, y) # Column bind  - Similar to merge
z
w = rbind(x, y) # Row bind - similar to append
w

a = matrix(1:10, nrow = 2, ncol = 5, byrow = TRUE)
a

b = matrix(sample(10:18, 10, replace = TRUE),
           nrow = 2,
           ncol = 5)
b

a * b # matrix multiplication
a + b # matrix addition

dim(a) # dimention of matrix a

cor(x, y) # Correlation

rownames(a) = c("S1", "S2")

colnames(a) =  c(2001, 2002, 2003, 2004, 2005)
a

# Transpose a matrix
trans = t(a)
trans

# Subsetting

trans[2,2]
trans["2001",]

# Installing a package
install.packages('tseries')

# Load a package
library(tseries)

# Check the installed packages

installed.packages()

# Importing a CSV file in R

stores = read.csv("./Test/stores.csv", header = TRUE)

# read.table for text files, read_excel for excel file using readxl package
# read_sas for sas datasets using haven package

str(stores) # Structure of dataset

summary(stores) # Discriptive statistcs
help(summary)
ncol(stores) # Number of columns in dataset
nrow(stores) # Number of rows in datset
dim(stores)  # dimensions
names(stores)# column names
head(stores) # Top 6 rows
tail(stores) # bottom 6 cols
View(stores) # View the dataset

install.packages("dplyr")
library(dplyr)

# Random sample from a dataset
sample_n(stores, 5)
sample_frac(stores,0.1)

write.csv(stores, "stores_r.csv") # file to be saved, file name of saved file

install.packages("foreign")
library(foreign)

write.foreign(stores, "stores.txt", "stores.sas",   package="SAS")

# Number of missing values
x="2"

as.numeric(x)
as.character(x)

colSums(is.na(stores)) # No. of missing values in each col

sum(is.na(stores$Tenure)) # No. of missing values in particular column

# Save

save.image() # saves workspace in current directory .Rdata
savehistory() # saves commands in current directory .Rhistory

# DataFrames - Used to combine variables of different data types

x = c(1,2,3,4,5)

y = c("a", "b", "c", "d", NA)

is.na(y)

data = data.frame(x,y)
data

# List
mylist = list(x,y,data)
mylist[1]
mylist[[3]]  # Check tutorials
mylist[[2]][3] # Subsets second element of list

# Create dummy data in R - similar to datalines in SAS

mydata = data.frame(Store_ID = c(2,3,4,5), Sales = c(200,300,400,450))
mydata

# Recoding 
typeof(stores$Staff_Cnt)
stores$Staff_Cnt[stores$Staff_Cnt == 60.0] = NA

install.packages("car")
library(car)
stores$Staff_Cnt = recode(stores$Staff_Cnt, 'lo:40 = "test"; 50:hi = NA')

# ifelse
stores$Staff_Cnt_cat = ifelse(stores$Staff_Cnt <=40,0,1) 

# Renaming
install.packages("dplyr")
library("dplyr")

stores = rename(stores, Dummy_cat = Staff_Cnt_cat )

# Keep and Delete Variables and subset data

stores3 = stores[-c(2:4)]

stores1$Dummy_cat = NULL

stores1 = subset(stores1, select = -c(1,2))

stores2 = subset(stores,Dummy_cat == 1)

# Sort a dataframe

stores = stores[order(stores$StoreCode),]

# Aggregate the data

Stores3 = aggregate(TotalSales~Location, stores, mean, na.rm = TRUE)
Stores3 = aggregate(stores$TotalSales, list(stores$Location,stores$StoreType), FUN = mean, na.rm = TRUE)

# Megre two datasets

Stores4 = merge(stores, Stores3, by=c("Location"))

# Duplicates

mydata = data.frame(Store_ID = c(2,3,2,5), Sales = c(2,3,2,5))
mydata


unique(mydata)  # NODUP in sas

subset(mydata, !duplicated(mydata[,c("Store_ID", "Sales")])) # Nodupkey in SAS

# Data Manipulation using DPLYR package
# Key concepts to remember 
#1 select
#2 join
#3 arrange
#4 summarise
#5 filter
#6 group_by
#7 mutate

# Remove duplicate rows 
mydata = distinct(mydata)
mydata

distinct(mydata, Store_ID, everything(), .keep_all= TRUE) # df, id, keeps all other variable

select(mydata, Store_ID, everything()) # df, ids

# starts_with, ends_with, contains, everything etc.

# rename(df, new_name = old_name) 

# Filter data

filter(mydata, Store_ID == 3)

# Summarise data / Aggregating data

summarise_at(mydata, vars(Sales), funs(n(), mean, median))

# summarise_if (mydata, is.numeric, funs(n(),mean,median))
# summarise_all (mydata, funs(n(),mean,median))
# arrange(mydata, Store_ID, Sales) - Sorting the data
# group_by(mydata, Store_ID)
# mutate(mydata, new_var = Post_Sales/Pre_Sales)
# inner_join(x, y, by = "Store_ID=STore", )
# left_join(x, y, by = "Store_ID")
# right_join(x, y, by = "Store_ID")
# full_join(x, y, by = "Store_ID")

#  For Loop

for(i in 1:5) {
  print("Hello Champ")
}

# While Loop

counter = 1
while (counter < 10) {
  print(counter)
  counter = counter + 1
}

# Apply Functions - hidden loops

dat <- data.frame(x = c(1:5,NA),
                  z = c(1, 1, 0, 0, NA,0),
                  y = 5*c(1:6))
dat

apply(dat, 2, max, na.rm= TRUE) # 1 corresponds to row level calculations
# applicated to dataframes and matrix and returns a vector

lapply(dat, function(x) median(x, na.rm = TRUE))
# applicable to dataframes and matrix and returns a list

sapply(dat, function(x) sum(is.na(x)))


# Explore sqldf package

mydata2 = sqldf("select a.*,b.Volume from mydata a left join (select distinct Store_ID from  mydata1) b
           on a.Store_ID = b.Store_ID ")

