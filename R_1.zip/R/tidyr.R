# set the working directory

setwd("D:\\z.Oms\\Learn.R\\Tidyr")
getwd()

# isntall the required packages if they are not installed

if(!require("tidyr")) install.packages("tidyr", dependencies = TRUE)
if(!require("devtools")) install.packages("devtools", dependencies = TRUE)

# load the required packages if they are not loaded 

library("tidyr", character.only = TRUE)
library("devtools", character.only = TRUE)

## OR

#use this function to check if each package is on the local machine
#if a package is installed, it will be loaded
#if any are not, the missing package(s) will be installed and loaded

if (!require("tidyr", character.only = TRUE)) {
  install.packages("tidyr", dependencies = TRUE)
  library("tidyr", character.only = TRUE)
}

if (!require("devtools", character.only = TRUE)) {
  install.packages("devtools", dependencies = TRUE)
  library("devtools", character.only = TRUE)
}

#### OR

#specify the packages of interest
packages = c("tidyr","devtools", "reshape2")

package.check <- lapply(packages, FUN = function(x) {
  if (!require(x, character.only = TRUE)) {
    install.packages(x, dependencies = TRUE)
    library(x, character.only = TRUE)
  }
})

#verify they are loaded
search()

# install the required dataset DSR from github

devtools::install_github("garrettgman/DSR")

library(DSR)

# data set 1
table1

# data set 2
table2

# data set 3
table3

# data set 4
table4

# data set 5
table5

################ NOTES ####################

# R follows a set of conventions that makes one layout of tabular data much easier to work with than others. Your data will be easier to work with in R if it follows three rules

# 1. Each variable in the data set is placed in its own column
# 2. Each observation is placed in its own row
# 3. Each value is placed in its own cell*

# Tidy data works well with R because R is a vectorized programming language. Data structures in R are built from vectors and R's operations are optimized to work with vectors. Tidy data takes advantage of both of these traits.

# R stores tabular data as a data frame, a list of atomic vectors arranged to look like a table. Each column in the table is an atomic vector in the list.

# A data frame is a list of vectors that R displays as a table. When your data is tidy, the values of each variable fall in their own column vector.


table1$cases
mean(table1$cases)
table1$cases / table1$population * 10000


??tidyr


table2
spread(table2, key, value)

####NOTES##########
# spread() turns a pair of key:value columns into a set of tidy columns.
# spread() distributes a pair of key:value columns into a field of cells. The unique values of the key column become the column names of the field of cells.

##### NOTES ######
# gather() does the reverse of spread(). gather() collects a set of column names and places them into a single "key" column. It also collects the cells of those columns and places them into a single value column.

table4

gather(table4, "year", "cases", 2:3)


table5
gather(table5, "year", "population", 2:3)

## OR
# gather(table5, "year", "population", c(2, 3))
# gather(table5, "year", "population", -1)

##### NOTES #####
# separate() turns a single character column into multiple columns by splitting the values of the column wherever a separator character appears.

table3

separate(table3, rate, into = c("cases", "population"))
# OR
# separate(table3, rate, into = c("cases", "population"), sep = "/")


separate(table3, year, into = c("century", "year"), sep = 2)


##### NOTES #####
# unite() does the opposite of separate(): it combines multiple columns into a single column.

table6

unite(table6, "new", century, year, sep = "")


######################### Case study ###############################3
View(who)


who = gather(who, "code", "value", 5:60)
head(who)
who = separate(who, code, into = c("new", "var","sexage"))
head(who)
who = separate(who, sexage, into = c("sex", "age"), sep = 1)
head(who)
str(who)

who <- spread(who, var, value)
head(who)
