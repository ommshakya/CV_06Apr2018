#D:\z.Oms\Learn.R\Dplyr
setwd("D:\\z.Oms\\Learn.R\\Dplyr")
getwd()

# First download the csv data file

library(downloader)
url <- "https://raw.githubusercontent.com/genomicsclass/dagdata/master/inst/extdata/msleep_ggplot2.csv"
filename <- "msleep_ggplot2.csv"
if (!file.exists(filename)) download(url, filename)
msleep <- read.csv("msleep_ggplot2.csv")

# See few observations of data
head(msleep)

# See the structure of the data
str(msleep)

# Confirm if the data set is a data frame
class(msleep)

## Load the dplyr package
library(dplyr)

# Take some help
??dplyr
??select

# Select a set of columns: the name and the sleep_total columns.
sleepData = select(msleep, name,sleep_total)
head(sleepData)

# To select all the columns except a specific column, use the "-" (subtraction) operator (also known as negative indexing)

head(select(msleep, -name))

# To select a range of columns by name, use the ":" (colon) operator
head(select(msleep, name:order))

# To select all columns that start with the character string "sl", use the function starts_with()
head(select(msleep, starts_with("sl")))

## Filter the rows for mammals that sleep a total of more than 16 hours.
filter(msleep, sleep_total >= 16)

# Filter the rows for mammals that sleep a total of more than 16 hours and have a body weight of greater than 1 kilogram.
filter(msleep, sleep_total >= 16 , bodywt >= 1)

# Filter the rows for mammals in the Perissodactyla and Primates taxonomic order
filter(msleep, order %in% c("Perissodactyla", "Primates"))

# Pipe operator: %>%
msleep %>% select(name, sleep_total) %>% head

# Arrange or re-order rows using arrange()
# To arrange (or re-order) rows by a particular column such as the taxonomic order, list the name of the #column you want to arrange the rows by

msleep %>% arrange(order) %>% head


#Now, we will select three columns from msleep, arrange the rows by the taxonomic order and then arrange the rows by sleep_total. Finally show the head of the final data frame

msleep %>% select(name, order, sleep_total) %>% arrange(order, sleep_total) %>% head

# Same as above, except here we filter the rows for mammals that sleep for 16 or more hours instead of showing the head of the final data frame

msleep %>% select(name, order, sleep_total) %>% arrange(order, sleep_total) %>% filter(sleep_total >= 16)

# Something slightly more complicated: same as above, except arrange the rows in the sleep_total column in a descending order. For this, use the function desc()

msleep %>% select(name, order, sleep_total) %>% arrange(order, desc(sleep_total)) %>% filter(sleep_total >= 16)

### Create new columns using mutate()
#The mutate() function will add new columns to the data frame. Create a new column called rem_proportion which is the ratio of rem sleep to total amount of sleep.

msleep %>% mutate(rem_proportion = sleep_rem/sleep_total) %>% head

# You can many new columns using mutate (separated by commas). Here we add a second column called bodywt_grams which is the bodywt column in grams.

msleep %>% mutate(rem_proportion = sleep_rem/sleep_total, bodywt_grams = bodywt * 1000) %>% head

### Create summaries of the data frame using summarise()

# The summarise() function will create summary statistics for a given column in the data frame such as finding the mean. For example, to compute the average number of hours of sleep, apply the mean() function to the column sleep_total and call the summary value avg_sleep.

msleep %>% summarize(avg_sleep = mean(sleep_total))

msleep %>% summarise(avg_sleep = mean(sleep_total), min_sleep = min(sleep_total), max_sleep = max(sleep_total), total = n())

# Group operations using group_by()
msleep %>% 
  group_by(order) %>%
  summarise(avg_sleep = mean(sleep_total), 
            min_sleep = min(sleep_total), 
            max_sleep = max(sleep_total),
            total = n())