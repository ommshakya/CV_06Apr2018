#first create a data frame for this study
alligator = data.frame(
  lnLength = c(3.87, 3.61, 4.33, 3.43, 3.81, 3.83, 3.46, 3.76,
               3.50, 3.58, 4.19, 3.78, 3.71, 3.73, 3.78),
  lnWeight = c(4.87, 3.93, 6.46, 3.33, 4.38, 4.70, 3.50, 4.50,
               3.58, 3.64, 5.90, 4.43, 4.38, 4.42, 4.25)
)

#As with most analysis the first step is to perform some exploratory data analysis to get 
#a visual impression of whether there is a relationship between weight and snout vent length 
#and what form it is likely to take. We create a scatter plot of the data as follows:
library(lattice)
xyplot(lnWeight ~ lnLength, data = alligator,
       xlab = "Snout vent length (inches) on log scale",
       ylab = "Weight (pounds) on log scale",
       main = "Alligators in Central Florida"
)

#The graph suggests that weight (on the log scale) increases linearly with snout vent length 
#(again on the log scale) so we will fit a simple linear regression model to the data and save the 
#fitted model to an object for further analysis:

alli.mod1 = lm(lnWeight ~ lnLength, data = alligator)
alli.mod1
summary(alli.mod1)


#A plot of the residuals against fitted values is used to determine whether there are any systematic 
#patterns, such as over estimation for most of the large values or increasing spread as the model 
#fitted values increase. To create this plot we could use the following code:

xyplot(resid(alli.mod1) ~ fitted(alli.mod1),
       xlab = "Fitted Values",
       ylab = "Residuals",
       main = "Residual Diagnostic Plot",
       panel = function(x, y, ...)
       {
         panel.grid(h = -1, v = -1)
         panel.abline(h = 0)
         panel.xyplot(x, y, ...)
       }
)
#The plot is probably ok but there are more cases of positive residuals and when we consider a normal 
#probability plot we see that there are some deficiencies with the model:

qqmath( ~ resid(alli.mod1),
        xlab = "Theoretical Quantiles",
        ylab = "Residuals"
)