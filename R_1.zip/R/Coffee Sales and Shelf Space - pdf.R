getwd()
setwd("d:\\oms\\r")

data = read.table("Space_Sales.txt")
class(data)
str(data)
names = c("shelf_width","sales")
colnames(data) = names
str(data)

plot(data)

model.lm = lm(sales~shelf_width, data = data)
model.lm
summary(model.lm)

coef = coefficients(model.lm)
coef[1]
coef[2]

#new_width = 1
new_width = data.frame(shelf_width=80)

coef[1] + coef[2] * new_width

abline(model.lm)

predict(model.lm, new_width, interval="confidence") 

#confidence interval of 95%, use any of the below

confint(model.lm)
confint(model.lm, "shelf_width")
