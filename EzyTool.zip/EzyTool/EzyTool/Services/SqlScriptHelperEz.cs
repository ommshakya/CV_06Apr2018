﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EzyTool.Services
{
    public static class SqlScriptHelperEz
    {
        public static string GenerateCreateTableScript(DataTable dataTable)
        {
            //https://stackoverflow.com/questions/1348712/creating-a-sql-server-table-from-a-c-sharp-datatable
            //https://social.msdn.microsoft.com/Forums/en-US/4929a0a8-0137-45f6-86e8-d11e220048c3/creating-a-new-table-in-sql-server-from-adonet-datatable?forum=adodotnetdataproviders
            string sqlsc;
            sqlsc = "IF OBJECT_ID('" + dataTable.TableName + "') IS NOT NULL \n DROP TABLE " + dataTable.TableName;
            sqlsc += "\n CREATE TABLE " + dataTable.TableName + "(";
            for (int i = 0; i < dataTable.Columns.Count; i++)
            {
                sqlsc += "\n [" + dataTable.Columns[i].ColumnName + "] ";
                string columnType = dataTable.Columns[i].DataType.ToString();
                switch (columnType)
                {
                    case "System.Int32":
                        sqlsc += " int ";
                        break;
                    case "System.Int64":
                        sqlsc += " bigint ";
                        break;
                    case "System.Int16":
                        sqlsc += " smallint";
                        break;
                    case "System.Byte":
                        sqlsc += " tinyint";
                        break;
                    case "System.Decimal":
                        sqlsc += " decimal ";
                        break;
                    case "System.DateTime":
                        sqlsc += " datetime ";
                        break;
                    case "System.String":
                    default:
                        sqlsc += string.Format(" nvarchar({0}) ", dataTable.Columns[i].MaxLength == -1 ? "max" : dataTable.Columns[i].MaxLength.ToString());
                        break;
                }
                if (dataTable.Columns[i].AutoIncrement)
                    sqlsc += " IDENTITY(" + dataTable.Columns[i].AutoIncrementSeed.ToString() + "," + dataTable.Columns[i].AutoIncrementStep.ToString() + ") ";
                if (!dataTable.Columns[i].AllowDBNull)
                    sqlsc += " NOT NULL ";
                sqlsc += ",";
            }
            return sqlsc.Substring(0, sqlsc.Length - 1) + "\n)";
        }
        public static string GenerateCreateSourceTableScript(DataTable dataTable, string fromTableName, string toSourceTableName)
        {
            string sql;
            sql = "IF OBJECT_ID('" + toSourceTableName + "') IS NOT NULL \n DROP TABLE " + toSourceTableName;
            sql += "\n SELECT ";
            sql += "\n IDENTITY(INT, 1, 1) AS EZY_ID";
            sql += ",";

            foreach (DataRow dr in dataTable.Rows)
            {
                sql += "\n [" + dr[0].ToString() + "]";
                sql += ",";

            }
            sql = sql.Substring(0, sql.Length - 1);

            sql += "\n INTO "+ toSourceTableName;
            sql += "\n FROM "+ fromTableName;
            return sql;
        }
        public static string GenerateCreateRenameColumnsScript(DataTable dataTable, string fromTableName, string toSourceTableName)
        {
            string sql = string.Empty;
            if (!fromTableName.Equals(toSourceTableName)) {
                sql = "IF OBJECT_ID('" + toSourceTableName + "') IS NOT NULL \n DROP TABLE " + toSourceTableName;

                sql += "\n SELECT ";
                sql += "\n IDENTITY(INT, 1, 1) AS EZY_ID";
                sql += ",";

                foreach (DataRow dr in dataTable.Rows)
                {
                    sql += "\n [" + dr[0].ToString() + "]" + " AS [" + dr[1].ToString() + "]";
                    sql += ",";

                }
                sql = sql.Substring(0, sql.Length - 1);
                sql += "\n INTO " + toSourceTableName;
                sql += "\n FROM " + fromTableName;
            }
            else
            {
                sql = "\n SELECT ";
                sql += "\n IDENTITY(INT, 1, 1) AS EZY_ID";
                sql += ",";

                foreach (DataRow dr in dataTable.Rows)
                {
                    sql += "\n [" + dr[0].ToString() + "]" + " AS [" + dr[1].ToString() + "]";
                    sql += ",";

                }
                sql = sql.Substring(0, sql.Length - 1);
                sql += "\n INTO " + toSourceTableName + "_TEMP";
                sql += "\n FROM " + fromTableName;

                sql += "\n\n DROP TABLE " + fromTableName;
                //sql += "\n\n sp_rename '" + toSourceTableName + "_TEMP'" + " , '" + toSourceTableName +"'" + ";"; 
                sql += "\n\n SELECT * INTO "+ toSourceTableName + " FROM "+ toSourceTableName + "_TEMP";
                sql += "\n\n DROP TABLE " + toSourceTableName + "_TEMP";
            }
            return sql;
        }
        public static string GenerateChangeCasesScript(DataTable dataTable, string toSourceTableName)
        {
            string sql;
            sql = "UPDATE " + toSourceTableName;
            sql += "\n SET ";


            //sql += "\n [EZY_ID] = [EZY_ID]";
            //sql += ",";

            foreach (DataRow dr in dataTable.Rows)
            {
                if (dr[1].ToString().Equals("LowerCase"))
                {
                    sql += "\n [" + dr[0].ToString() + "]" + " = LOWER([" + dr[0].ToString() + "])";
                    sql += ",";
                }
                if (dr[1].ToString().Equals("UpperCase"))
                {
                    sql += "\n [" + dr[0].ToString() + "]" + " = UPPER([" + dr[0].ToString() + "])";
                    sql += ",";
                }
                if (dr[1].ToString().Equals("ProperCase"))
                {
                    //sql += "\n [" + dr[0].ToString() + "]" + " = LOWER([" + dr[0].ToString() + "])";
                    //sql += ",";
                }
            }
            sql = sql.Substring(0, sql.Length - 1);

            sql += "; ";
            return sql;
        }
        public static string GenerateChangeDateFormatScript(DataTable dataTable, string toSourceTableName) // Working here // TO BE IMPLEMENTED
        {
            string sql;
            sql = "UPDATE " + toSourceTableName;
            sql += "\n SET ";

            //sql += "\n [EZY_ID] = [EZY_ID]";
            //sql += ",";

            foreach (DataRow dr in dataTable.Rows)
            {
                if (dr[1].ToString().Equals("LowerCase"))
                {
                    sql += "\n [" + dr[0].ToString() + "]" + " = LOWER([" + dr[0].ToString() + "])";
                    sql += ",";
                }
                if (dr[1].ToString().Equals("UpperCase"))
                {
                    sql += "\n [" + dr[0].ToString() + "]" + " = UPPER([" + dr[0].ToString() + "])";
                    sql += ",";
                }
                if (dr[1].ToString().Equals("ProperCase"))
                {
                    //sql += "\n [" + dr[0].ToString() + "]" + " = LOWER([" + dr[0].ToString() + "])";
                    //sql += ",";
                }
            }
            sql = sql.Substring(0, sql.Length - 1);

            sql += "; ";
            return sql;
        }
        public static List<string> GenerateReplaceValuesScript(DataTable dataTable, string toSourceTableName)
        {
            List<string> listOfQueries = new List<string>();
            //string sql;
            //sql = "UPDATE " + toSourceTableName;
            //sql += "\n SET ";

            string column = string.Empty;
            string valueToReplace = string.Empty;
            string replcaeByValue = string.Empty;
            string derivedColumn = string.Empty;
            foreach (DataRow dr in dataTable.Rows)
            {
                string query = string.Empty;
                //sql += "\n [" + dr[0].ToString() + "]" + " = REPLACE([" + dr[0].ToString() + "], \'"+ dr[1].ToString() + "\' , \'" + dr[2].ToString() + "\')";
                //sql += ",";
                column = dr[0].ToString();
                valueToReplace = dr[1].ToString();
                replcaeByValue = dr[2].ToString();
                derivedColumn = dr[0].ToString() + "_UPD";

                query += string.Format(@"
                            IF OBJECT_ID('TempDB.dbo.#SPLITING_SOURCE') IS NOT NULL
	                            DROP TABLE #SPLITING_SOURCE

                            SELECT EZY_ID, [{1}]
                            INTO #SPLITING_SOURCE
                            FROM {0}

                            UPDATE {0} SET [{1}] = [{4}]
                            FROM {0} AS B
                            JOIN 
                            (
	                            SELECT EZY_ID, TRIM(STRING_AGG(value_upd, ' '))  AS [{4}] 
                                FROM (
	                                    SELECT  EZY_ID, value, CASE WHEN value = '{2}' THEN REPLACE(value, '{2}', '{3}') ELSE value END AS value_upd
		                                FROM #SPLITING_SOURCE  
			                            CROSS APPLY STRING_SPLIT([{1}], ' ')
	                            ) AS A
	                            GROUP BY EZY_ID
                            ) AS C ON B.EZY_ID = C.EZY_ID
                            ", toSourceTableName, column, valueToReplace, replcaeByValue, derivedColumn);
                query += "\n";

                query += "; ";
                listOfQueries.Add(query);
            }
            //sql = sql.Substring(0, sql.Length - 1);

            return listOfQueries;
        }
        public static List<string> GenerateRemoveWhiteSpacesScript(DataTable dataTable, string toSourceTableName)
        {
            List<string> listOfQueries = new List<string>();
            //string sql;
            //sql = "UPDATE " + toSourceTableName;
            //sql += "\n SET ";

            string column = string.Empty;
            string valueToReplace = string.Empty;
            string replcaeByValue = string.Empty;
            string derivedColumn = string.Empty;
            foreach (DataRow dr in dataTable.Rows)
            {
                string query = string.Empty;
                //sql += "\n [" + dr[0].ToString() + "]" + " = REPLACE([" + dr[0].ToString() + "], \'"+ dr[1].ToString() + "\' , \'" + dr[2].ToString() + "\')";
                //sql += ",";
                column = dr[0].ToString();
                //valueToReplace = dr[1].ToString();
                //replcaeByValue = dr[2].ToString();
                derivedColumn = dr[0].ToString() + "_UPD";

                query += string.Format(@"
                            IF OBJECT_ID('TempDB.dbo.#SPLITING_SOURCE') IS NOT NULL
	                            DROP TABLE #SPLITING_SOURCE

                            SELECT EZY_ID, [{1}]
                            INTO #SPLITING_SOURCE
                            FROM {0}

                            UPDATE {0} SET [{1}] = [{2}]
                            FROM {0} AS B
                            JOIN 
                            (
	                            SELECT EZY_ID, TRIM(STRING_AGG(value, ' '))  AS [{2}] 
                                FROM (
	                                    SELECT  EZY_ID, value
		                                FROM #SPLITING_SOURCE  
			                            CROSS APPLY STRING_SPLIT([{1}], ' ') WHERE LTRIM(RTRIM(value)) <> ''
	                            ) AS A
	                            GROUP BY EZY_ID
                            ) AS C ON B.EZY_ID = C.EZY_ID
                            ", toSourceTableName, column, derivedColumn);
                query += "\n";

                query += "; ";
                listOfQueries.Add(query);
            }
            //sql = sql.Substring(0, sql.Length - 1);
            
            return listOfQueries;
        }
    }
}
