﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EzyTool.Services
{
    public static class SqlDbAccessHelperEz
    {
        public static void LoadDataTableIntoSql(DataTable dt)
        {
            string conn = ConfigurationManager.ConnectionStrings["EzyTool.Properties.Settings.DBEzyToolConnectionString"].ConnectionString;
            SqlBulkCopy bulkCopy = new SqlBulkCopy(conn);
            bulkCopy.DestinationTableName = dt.TableName;
            try
            {
                bulkCopy.WriteToServer(dt);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                bulkCopy.Close();
            }
        }
        public static DataTable ExecuteGetData(string sqlselectquery)
        {
            string conStr = ConfigurationManager.ConnectionStrings["EzyTool.Properties.Settings.DBEzyToolConnectionString"].ToString();
            SqlConnection sqlConnection1 = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            //SqlDataReader reader;

            cmd.CommandText = sqlselectquery;// "SELECT * FROM TBL";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = sqlConnection1;

            sqlConnection1.Open();

            //reader = cmd.ExecuteReader();
            // Data is accessible through the DataReader object here.

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            //dgvShowDetails.DataSource = dt;
            sqlConnection1.Close();

            return dt;
        }
        public static void ExecuteSqlCommand(string sqlcommandtext)
        {
            string connetionString = null;
            SqlConnection cnn;
            SqlCommand cmd;
            string sql = null;

            connetionString = ConfigurationManager.ConnectionStrings["EzyTool.Properties.Settings.DBEzyToolConnectionString"].ToString();
            sql = sqlcommandtext;

            cnn = new SqlConnection(connetionString);
            try
            {
                cnn.Open();
                cmd = new SqlCommand(sql, cnn);
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                cnn.Close();
                //MessageBox.Show(" ExecuteNonQuery in SqlCommand executed !!");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                cnn.Close();
            }
        }
    }
}
