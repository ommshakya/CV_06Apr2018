﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EzyTool.Services
{
    public static class DataTableHelperEz
    {
        public static DataTable GenerateListToRemoveWhiteSpaces(DataTable dt)
        {
            DataTable dtColumnList = new DataTable();
            dtColumnList.Columns.Add("ColumnIndex", typeof(int));
            dtColumnList.Columns.Add("ExistingColumnName", typeof(string));
            int index = 1;
            foreach (DataColumn column in dt.Columns)
            {
                if (!column.ColumnName.Equals("EzID") && !column.ColumnName.Equals("EZY_ID"))
                {
                    if (column.DataType.Name.Equals("String"))
                    {
                        dtColumnList.Rows.Add(index, column.ColumnName);
                        index++;
                    }
                }
            }
            return dtColumnList;
        }
        public static DataTable GenerateListToSourceColumns(DataTable dt)
        {
            DataTable dtColumnList = new DataTable();
            dtColumnList.Columns.Add("ColumnIndex", typeof(int));
            dtColumnList.Columns.Add("ExistingColumnName", typeof(string));
            int index = 1;
            foreach (DataColumn column in dt.Columns)
            {
                if (!column.ColumnName.Equals("EzID") && !column.ColumnName.Equals("EZY_ID"))
                {
                    dtColumnList.Rows.Add(index, column.ColumnName);
                    index++;
                }
            }
            return dtColumnList;
        }
        public static DataTable GenerateListOfColumnsToReplaceValues(DataTable dt)
        {
            DataTable dtColumnList = new DataTable();
            dtColumnList.Columns.Add("ColumnNameValue", typeof(string));
            dtColumnList.Columns.Add("ColumnNameText", typeof(string));
            //int index = 1;
            dtColumnList.Rows.Add("SelectColumn", "Select column");
            if (dt != null)
                foreach (DataColumn column in dt.Columns)
                {
                    if (!column.ColumnName.Equals("EzID") && !column.ColumnName.Equals("EZY_ID"))
                    {
                        if (column.DataType.Name.Equals("String"))
                        {
                            dtColumnList.Rows.Add(column.ColumnName, column.ColumnName);
                            //index++;
                        }
                    }
                }
            return dtColumnList;
        }
        public static DataTable GenerateListToReplaceValues()//DataTable dt)
        {
            DataTable dtColumnList = new DataTable();
            dtColumnList.Columns.Add("ColumnNum", typeof(string));
            dtColumnList.Columns.Add("ExistingColumnValue", typeof(string));
            dtColumnList.Columns.Add("ReplaceByValue", typeof(string));
            //int index = 1;
            //foreach (DataColumn column in dt.Columns)
            //{
            //    dtColumnList.Rows.Add(index, column.ColumnName);
            //    index++;
            //}
            //dtColumnList.Rows.Add(index, string.Empty);
            dtColumnList.Rows.Add(string.Empty, string.Empty, string.Empty);
            return dtColumnList;
        }
        public static DataTable GenerateListToChangeDateFormat(DataTable dt)
        {
            DataTable dtColumnList = new DataTable();
            dtColumnList.Columns.Add("ColumnNum", typeof(int));
            dtColumnList.Columns.Add("ExistingColumnName", typeof(string));
            int index = 1;
            foreach (DataColumn column in dt.Columns)
            {
                if (!column.ColumnName.Equals("EzID") && !column.ColumnName.Equals("EZY_ID"))
                {
                    if (column.DataType.Name.Equals("DateTime"))
                    {
                        dtColumnList.Rows.Add(index, column.ColumnName);
                        index++;
                    }
                }
            }
            return dtColumnList;
        }
        public static DataTable GenerateListToChangeCases(DataTable dt)
        {
            DataTable dtColumnList = new DataTable();
            dtColumnList.Columns.Add("ColumnNum", typeof(int));
            dtColumnList.Columns.Add("ExistingColumnName", typeof(string));
            int index = 1;
            foreach (DataColumn column in dt.Columns)
            {
                if (!column.ColumnName.Equals("EzID") && !column.ColumnName.Equals("EZY_ID"))
                {
                    if (column.DataType.Name.Equals("String"))
                    {
                        dtColumnList.Rows.Add(index, column.ColumnName);
                        index++;
                    }
                }
            }
            return dtColumnList;
        }
        public static DataTable GenerateListToRenameColumns(DataTable dt)
        {
            DataTable dtColumnList = new DataTable();
            dtColumnList.Columns.Add("ColumnIndex", typeof(int));
            dtColumnList.Columns.Add("ExistingColumnName", typeof(string));
            dtColumnList.Columns.Add("RenameColumnName", typeof(string));
            int index = 1;
            foreach (DataColumn column in dt.Columns)
            {
                if (!column.ColumnName.Equals("EzID") && !column.ColumnName.Equals("EZY_ID"))
                {
                    dtColumnList.Rows.Add(index, column.ColumnName, string.Empty);
                    index++;
                }
            }
            return dtColumnList;
        }
        public static int getIndexOfKey(Dictionary<string, string> tempDict, String key)
        {
            int index = -1;
            foreach (String value in tempDict.Keys)
            {
                index++;
                if (key == value)
                    return index;
            }
            return -1;
        }
    }
}
