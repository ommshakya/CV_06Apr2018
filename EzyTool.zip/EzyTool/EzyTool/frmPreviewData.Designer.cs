﻿namespace EzyTool
{
    partial class frmPreviewData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPageRawData = new System.Windows.Forms.TabPage();
            this.dgvShowDetails = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tabPageSourceData = new System.Windows.Forms.TabPage();
            this.dgvSourceData = new System.Windows.Forms.DataGridView();
            this.tabPageDuplicatedData = new System.Windows.Forms.TabPage();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPageRawData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvShowDetails)).BeginInit();
            this.tabPageSourceData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSourceData)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageRawData);
            this.tabControl1.Controls.Add(this.tabPageSourceData);
            this.tabControl1.Controls.Add(this.tabPageDuplicatedData);
            this.tabControl1.Location = new System.Drawing.Point(2, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(754, 444);
            this.tabControl1.TabIndex = 15;
            // 
            // tabPageRawData
            // 
            this.tabPageRawData.Controls.Add(this.dgvShowDetails);
            this.tabPageRawData.Controls.Add(this.button1);
            this.tabPageRawData.Controls.Add(this.comboBox2);
            this.tabPageRawData.Controls.Add(this.comboBox1);
            this.tabPageRawData.Location = new System.Drawing.Point(4, 22);
            this.tabPageRawData.Name = "tabPageRawData";
            this.tabPageRawData.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageRawData.Size = new System.Drawing.Size(746, 418);
            this.tabPageRawData.TabIndex = 0;
            this.tabPageRawData.Text = "Raw Data";
            this.tabPageRawData.UseVisualStyleBackColor = true;
            // 
            // dgvShowDetails
            // 
            this.dgvShowDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvShowDetails.Location = new System.Drawing.Point(2, 27);
            this.dgvShowDetails.Name = "dgvShowDetails";
            this.dgvShowDetails.Size = new System.Drawing.Size(741, 388);
            this.dgvShowDetails.TabIndex = 18;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(707, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(36, 23);
            this.button1.TabIndex = 17;
            this.button1.Text = "csv";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(2, 3);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(431, 21);
            this.comboBox2.TabIndex = 16;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(443, 3);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 15;
            // 
            // tabPageSourceData
            // 
            this.tabPageSourceData.Controls.Add(this.dgvSourceData);
            this.tabPageSourceData.Location = new System.Drawing.Point(4, 22);
            this.tabPageSourceData.Name = "tabPageSourceData";
            this.tabPageSourceData.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSourceData.Size = new System.Drawing.Size(746, 418);
            this.tabPageSourceData.TabIndex = 2;
            this.tabPageSourceData.Text = "Source Data";
            this.tabPageSourceData.UseVisualStyleBackColor = true;
            // 
            // dgvSourceData
            // 
            this.dgvSourceData.AllowUserToDeleteRows = false;
            this.dgvSourceData.AllowUserToResizeRows = false;
            this.dgvSourceData.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dgvSourceData.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Red;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSourceData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSourceData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSourceData.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvSourceData.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvSourceData.Location = new System.Drawing.Point(2, 0);
            this.dgvSourceData.MultiSelect = false;
            this.dgvSourceData.Name = "dgvSourceData";
            this.dgvSourceData.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSourceData.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvSourceData.RowHeadersVisible = false;
            this.dgvSourceData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSourceData.Size = new System.Drawing.Size(743, 387);
            this.dgvSourceData.TabIndex = 15;
            // 
            // tabPageDuplicatedData
            // 
            this.tabPageDuplicatedData.Location = new System.Drawing.Point(4, 22);
            this.tabPageDuplicatedData.Name = "tabPageDuplicatedData";
            this.tabPageDuplicatedData.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDuplicatedData.Size = new System.Drawing.Size(746, 418);
            this.tabPageDuplicatedData.TabIndex = 1;
            this.tabPageDuplicatedData.Text = "Duplicated Data";
            this.tabPageDuplicatedData.UseVisualStyleBackColor = true;
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(670, 453);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(82, 23);
            this.btnClose.TabIndex = 16;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(582, 453);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(82, 23);
            this.btnOk.TabIndex = 17;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            // 
            // frmPreviewData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 525);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmPreviewData";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Ezy Data Preview ™";
            this.tabControl1.ResumeLayout(false);
            this.tabPageRawData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvShowDetails)).EndInit();
            this.tabPageSourceData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSourceData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnOk;
        public System.Windows.Forms.TabControl tabControl1;
        public System.Windows.Forms.TabPage tabPageRawData;
        public System.Windows.Forms.TabPage tabPageDuplicatedData;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.TabPage tabPageSourceData;
        public System.Windows.Forms.DataGridView dgvSourceData;
        protected internal System.Windows.Forms.DataGridView dgvShowDetails;
    }
}