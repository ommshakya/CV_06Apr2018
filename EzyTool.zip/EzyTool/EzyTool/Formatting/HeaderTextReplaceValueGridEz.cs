﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EzyTool.Formatting
{
    public static class HeaderTextReplaceValueGridEz
    {

        public static string SelectColumn
        {
            get
            {
                return "Select column";
            }
        }

        public static string ExistingColumnValue
        {
            get
            {
                return "Existing column value";
            }
        }
        public static string ColumnIndex
        {
            get
            {
                return "";
            }
        }
        public static string ReplaceByValue
        {
            get
            {
                return "Replace by value";
            }
        }
    }
}
