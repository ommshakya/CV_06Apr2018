﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EzyTool.Formatting
{
    public static class HeaderTextRemoveWhiteSpacesGridEz
    {

        public static string ColumnIndex
        {
            get
            {
                return "";
            }
        }
        public static string SelectColumn
        {
            get
            {
                return "";//Select
            }
        }
        public static string ExistingColumnName
        {
            get
            {
                return "Column name";
            }
        }
    }
}
