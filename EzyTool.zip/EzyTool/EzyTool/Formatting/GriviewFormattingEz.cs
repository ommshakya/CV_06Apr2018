﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EzyTool.Formatting
{
    public static class GriviewFormattingEz
    {
        public static Color GridviewSelectedBackgroundColor
        {
            get
            {
                return Color.Transparent;
            }
        }
        public static Color HeaderCellBackgroundColor
        {
            get
            {
                return Color.LightGray;
            }
        }
        public static Color DataCellBackgroundColor
        {
            get
            {
                return Color.White;
            }
        }
        public static Color DataCellSelectedColor
        {
            get
            {
                return Color.WhiteSmoke;
            }
        }
        public static Font HeaderFontStyle
        {
            get
            {
                return new Font("Corbel", 9.5F, FontStyle.Regular);
            }
        }
        public static bool ReadOnly
        {
            get
            {
                return false;
            }
        }
        public static bool AllowUserToAddRows
        {
            get
            {
                return false;
            }
        }
        public static int Height
        {
            get
            {
                return 223;// 196;
            }
        }
        public static int ColumnHeaderHeight
        {
            get
            {
                return 25;
            }
        }
        public static BorderStyle BorderStyle
        {
            get
            {
                return BorderStyle.None;
            }
        }
        public static DataGridViewEditMode DataGridViewEditMode
        {
            get
            {
                return DataGridViewEditMode.EditOnEnter;
            }
        }
        public static Color BackgroundColor
        {
            get
            {
                return Color.White;
            }
        }
        public static bool EnableHeadersVisualStyles
        {
            get
            {
                return false;
            }
        }
        public static void FormatCsvGridView(DataGridView dataGridView)
        {
            FormatGridView(dataGridView);

            //Set additional properties specific to this data grid
            dataGridView.Height = 191;
            dataGridView.ColumnHeadersDefaultCellStyle.Font = new Font("Corbel", 8.5F, FontStyle.Regular);
            dataGridView.DefaultCellStyle.BackColor = DataCellBackgroundColor;
            dataGridView.DefaultCellStyle.SelectionBackColor = DataCellSelectedColor;
            dataGridView.ReadOnly = true;

            //Show the row headers and set the background color
            dataGridView.RowHeadersVisible = true;
            dataGridView.RowHeadersDefaultCellStyle.BackColor = DataCellBackgroundColor;
            dataGridView.RowHeadersDefaultCellStyle.SelectionBackColor = DataCellSelectedColor;

        }

        public static void FormatGridView(DataGridView dataGridView)
        {
            dataGridView.DefaultCellStyle.Font = new Font("Corbel", 9.0F, FontStyle.Regular);
            dataGridView.DefaultCellStyle.SelectionBackColor = GridviewSelectedBackgroundColor;
            dataGridView.ColumnHeadersDefaultCellStyle.BackColor = HeaderCellBackgroundColor;
            dataGridView.ColumnHeadersDefaultCellStyle.Font = HeaderFontStyle;
            dataGridView.AllowUserToAddRows = AllowUserToAddRows;
            dataGridView.EditMode = DataGridViewEditMode;
            dataGridView.BorderStyle = BorderStyle;
            dataGridView.ReadOnly = ReadOnly;
            //dataGridView.Height = Height;
            dataGridView.ColumnHeadersHeight = ColumnHeaderHeight;
            dataGridView.BackgroundColor = BackgroundColor;
            dataGridView.EnableHeadersVisualStyles = EnableHeadersVisualStyles;

            //Prevent sorting
            foreach (DataGridViewColumn col in dataGridView.Columns)
                col.SortMode = DataGridViewColumnSortMode.NotSortable;
                    
        }
        public static void FormatGridViewCustomColumn(DataGridViewColumn dataGridViewColumn)
        {
            dataGridViewColumn.DefaultCellStyle.BackColor = DataCellBackgroundColor;
            dataGridViewColumn.DefaultCellStyle.SelectionBackColor = DataCellSelectedColor;
        }
    }
}
