﻿namespace EzyTool
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnImportCsvFile = new System.Windows.Forms.Button();
            this.btnExportToCsv = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPageSourceColumns = new System.Windows.Forms.TabPage();
            this.tblSC = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.chkBoxSourceColumnsSelectAll = new System.Windows.Forms.CheckBox();
            this.btnCancelSourceColumns = new System.Windows.Forms.Button();
            this.btnProcessSourceColumns = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dgvSOurceColumns = new System.Windows.Forms.DataGridView();
            this.tabPageRenameColumns = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btnCancelRenameColumns = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxHeaderCase = new System.Windows.Forms.ComboBox();
            this.btnProcessRenameColumns = new System.Windows.Forms.Button();
            this.dgvRenameColumns = new System.Windows.Forms.DataGridView();
            this.tabPageChangeCases = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.chkBoxChoosecaseSelectAll = new System.Windows.Forms.CheckBox();
            this.btnCancelChangeCases = new System.Windows.Forms.Button();
            this.cmbBoxChoosecaseSelectAll = new System.Windows.Forms.ComboBox();
            this.btnProcessChangeCases = new System.Windows.Forms.Button();
            this.dgvChangeCases = new System.Windows.Forms.DataGridView();
            this.tabPageChangeDateFormat = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.chkBoxChooseDateFormatSelectAll = new System.Windows.Forms.CheckBox();
            this.btnCancelChooseDateFormat = new System.Windows.Forms.Button();
            this.btnProcessChangeDateFormat = new System.Windows.Forms.Button();
            this.cmbBoxChooseDateFormatSelectAll = new System.Windows.Forms.ComboBox();
            this.dgvChangeDateFormat = new System.Windows.Forms.DataGridView();
            this.tabPageReplaceValues = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel10 = new System.Windows.Forms.TableLayoutPanel();
            this.btnProcessReplaceValues = new System.Windows.Forms.Button();
            this.btnCancelReplaceValues = new System.Windows.Forms.Button();
            this.dgvReplaceValue = new System.Windows.Forms.DataGridView();
            this.tabPageRemoveWhiteSpaces = new System.Windows.Forms.TabPage();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel11 = new System.Windows.Forms.TableLayoutPanel();
            this.chkBoxRemoveWhiteSpacesSelectAll = new System.Windows.Forms.CheckBox();
            this.btnCancelRemoveWhiteSpaces = new System.Windows.Forms.Button();
            this.btnProcessRemoveWhiteSpaces = new System.Windows.Forms.Button();
            this.dgvRemoveWhiteSpaces = new System.Windows.Forms.DataGridView();
            this.tabPageOutputFields = new System.Windows.Forms.TabPage();
            this.btnPreviewData = new System.Windows.Forms.Button();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.chkBoxEnableSourceColumnsTab = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvShowDetails = new System.Windows.Forms.DataGridView();
            this.comboBoxDataExportFileType = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvStepsDone = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.automateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.lblDimension = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tableMiddleBlock = new System.Windows.Forms.TableLayoutPanel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tableLeftBlock = new System.Windows.Forms.TableLayoutPanel();
            this.panelRightBlock = new System.Windows.Forms.Panel();
            this.tableRightBlock = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.Column1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl.SuspendLayout();
            this.tabPageSourceColumns.SuspendLayout();
            this.tblSC.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSOurceColumns)).BeginInit();
            this.tabPageRenameColumns.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRenameColumns)).BeginInit();
            this.tabPageChangeCases.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel9.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChangeCases)).BeginInit();
            this.tabPageChangeDateFormat.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.panel10.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChangeDateFormat)).BeginInit();
            this.tabPageReplaceValues.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.panel11.SuspendLayout();
            this.tableLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReplaceValue)).BeginInit();
            this.tabPageRemoveWhiteSpaces.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.panel12.SuspendLayout();
            this.tableLayoutPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRemoveWhiteSpaces)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvShowDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStepsDone)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableMiddleBlock.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tableLeftBlock.SuspendLayout();
            this.panelRightBlock.SuspendLayout();
            this.tableRightBlock.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnImportCsvFile
            // 
            this.btnImportCsvFile.Location = new System.Drawing.Point(401, 3);
            this.btnImportCsvFile.Name = "btnImportCsvFile";
            this.btnImportCsvFile.Size = new System.Drawing.Size(120, 23);
            this.btnImportCsvFile.TabIndex = 2;
            this.btnImportCsvFile.Text = "Browse file ...";
            this.btnImportCsvFile.UseVisualStyleBackColor = true;
            this.btnImportCsvFile.Click += new System.EventHandler(this.btnImportCsvFile_Click);
            // 
            // btnExportToCsv
            // 
            this.btnExportToCsv.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnExportToCsv.Location = new System.Drawing.Point(3, 421);
            this.btnExportToCsv.Name = "btnExportToCsv";
            this.btnExportToCsv.Size = new System.Drawing.Size(278, 30);
            this.btnExportToCsv.TabIndex = 5;
            this.btnExportToCsv.Text = "Export Data";
            this.btnExportToCsv.UseVisualStyleBackColor = true;
            this.btnExportToCsv.Click += new System.EventHandler(this.btnExportToCsv_Click);
            // 
            // tabControl
            // 
            this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableMiddleBlock.SetColumnSpan(this.tabControl, 2);
            this.tabControl.Controls.Add(this.tabPageSourceColumns);
            this.tabControl.Controls.Add(this.tabPageRenameColumns);
            this.tabControl.Controls.Add(this.tabPageChangeCases);
            this.tabControl.Controls.Add(this.tabPageChangeDateFormat);
            this.tabControl.Controls.Add(this.tabPageReplaceValues);
            this.tabControl.Controls.Add(this.tabPageRemoveWhiteSpaces);
            this.tabControl.Controls.Add(this.tabPageOutputFields);
            this.tabControl.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl.Location = new System.Drawing.Point(3, 31);
            this.tabControl.Multiline = true;
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(922, 307);
            this.tabControl.TabIndex = 12;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
            // 
            // tabPageSourceColumns
            // 
            this.tabPageSourceColumns.BackColor = System.Drawing.Color.White;
            this.tabPageSourceColumns.Controls.Add(this.tblSC);
            this.tabPageSourceColumns.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageSourceColumns.Location = new System.Drawing.Point(4, 24);
            this.tabPageSourceColumns.Name = "tabPageSourceColumns";
            this.tabPageSourceColumns.Size = new System.Drawing.Size(914, 279);
            this.tabPageSourceColumns.TabIndex = 6;
            this.tabPageSourceColumns.Text = "Source columns";
            // 
            // tblSC
            // 
            this.tblSC.ColumnCount = 1;
            this.tblSC.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblSC.Controls.Add(this.panel2, 0, 1);
            this.tblSC.Controls.Add(this.panel7, 0, 0);
            this.tblSC.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblSC.Location = new System.Drawing.Point(0, 0);
            this.tblSC.Name = "tblSC";
            this.tblSC.RowCount = 2;
            this.tblSC.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblSC.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tblSC.Size = new System.Drawing.Size(914, 279);
            this.tblSC.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 242);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(908, 34);
            this.panel2.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.chkBoxSourceColumnsSelectAll, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnCancelSourceColumns, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnProcessSourceColumns, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(908, 34);
            this.tableLayoutPanel1.TabIndex = 10;
            // 
            // chkBoxSourceColumnsSelectAll
            // 
            this.chkBoxSourceColumnsSelectAll.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chkBoxSourceColumnsSelectAll.BackColor = System.Drawing.Color.LightGray;
            this.chkBoxSourceColumnsSelectAll.Location = new System.Drawing.Point(3, 10);
            this.chkBoxSourceColumnsSelectAll.Name = "chkBoxSourceColumnsSelectAll";
            this.chkBoxSourceColumnsSelectAll.Size = new System.Drawing.Size(15, 14);
            this.chkBoxSourceColumnsSelectAll.TabIndex = 9;
            this.chkBoxSourceColumnsSelectAll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkBoxSourceColumnsSelectAll.UseVisualStyleBackColor = false;
            this.chkBoxSourceColumnsSelectAll.Click += new System.EventHandler(this.chkBoxSourceColumnsSelectAll_Click);
            // 
            // btnCancelSourceColumns
            // 
            this.btnCancelSourceColumns.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnCancelSourceColumns.Location = new System.Drawing.Point(829, 5);
            this.btnCancelSourceColumns.Name = "btnCancelSourceColumns";
            this.btnCancelSourceColumns.Size = new System.Drawing.Size(75, 23);
            this.btnCancelSourceColumns.TabIndex = 8;
            this.btnCancelSourceColumns.Text = "Cancel";
            this.btnCancelSourceColumns.UseVisualStyleBackColor = true;
            this.btnCancelSourceColumns.Click += new System.EventHandler(this.btnCancelSourceColumns_Click);
            // 
            // btnProcessSourceColumns
            // 
            this.btnProcessSourceColumns.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnProcessSourceColumns.Location = new System.Drawing.Point(748, 5);
            this.btnProcessSourceColumns.Name = "btnProcessSourceColumns";
            this.btnProcessSourceColumns.Size = new System.Drawing.Size(75, 23);
            this.btnProcessSourceColumns.TabIndex = 7;
            this.btnProcessSourceColumns.Text = "Process";
            this.btnProcessSourceColumns.UseVisualStyleBackColor = true;
            this.btnProcessSourceColumns.Click += new System.EventHandler(this.btnProcessSourceColumns_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.dgvSOurceColumns);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(908, 233);
            this.panel7.TabIndex = 1;
            // 
            // dgvSOurceColumns
            // 
            this.dgvSOurceColumns.AllowUserToAddRows = false;
            this.dgvSOurceColumns.AllowUserToDeleteRows = false;
            this.dgvSOurceColumns.AllowUserToResizeRows = false;
            this.dgvSOurceColumns.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dgvSOurceColumns.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Red;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSOurceColumns.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSOurceColumns.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvSOurceColumns.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvSOurceColumns.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSOurceColumns.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvSOurceColumns.Location = new System.Drawing.Point(0, 0);
            this.dgvSOurceColumns.MultiSelect = false;
            this.dgvSOurceColumns.Name = "dgvSOurceColumns";
            this.dgvSOurceColumns.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvSOurceColumns.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvSOurceColumns.RowHeadersVisible = false;
            this.dgvSOurceColumns.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvSOurceColumns.Size = new System.Drawing.Size(908, 233);
            this.dgvSOurceColumns.TabIndex = 6;
            this.dgvSOurceColumns.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSOurceColumns_CellContentClick);
            // 
            // tabPageRenameColumns
            // 
            this.tabPageRenameColumns.BackColor = System.Drawing.Color.White;
            this.tabPageRenameColumns.Controls.Add(this.tableLayoutPanel4);
            this.tabPageRenameColumns.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageRenameColumns.Location = new System.Drawing.Point(4, 24);
            this.tabPageRenameColumns.Name = "tabPageRenameColumns";
            this.tabPageRenameColumns.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageRenameColumns.Size = new System.Drawing.Size(914, 279);
            this.tabPageRenameColumns.TabIndex = 0;
            this.tabPageRenameColumns.Text = "Rename columns";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Controls.Add(this.panel8, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.dgvRenameColumns, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.Size = new System.Drawing.Size(908, 273);
            this.tableLayoutPanel4.TabIndex = 16;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.tableLayoutPanel2);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(3, 233);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(902, 37);
            this.panel8.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.btnCancelRenameColumns, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.panel6, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnProcessRenameColumns, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(902, 37);
            this.tableLayoutPanel2.TabIndex = 16;
            // 
            // btnCancelRenameColumns
            // 
            this.btnCancelRenameColumns.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnCancelRenameColumns.Location = new System.Drawing.Point(824, 7);
            this.btnCancelRenameColumns.Name = "btnCancelRenameColumns";
            this.btnCancelRenameColumns.Size = new System.Drawing.Size(75, 23);
            this.btnCancelRenameColumns.TabIndex = 10;
            this.btnCancelRenameColumns.Text = "Cancel";
            this.btnCancelRenameColumns.UseVisualStyleBackColor = true;
            this.btnCancelRenameColumns.Click += new System.EventHandler(this.btnCancelRenameColumns_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.comboBoxHeaderCase);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(3, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(262, 31);
            this.panel6.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 15);
            this.label1.TabIndex = 15;
            this.label1.Text = "Change column headers to :";
            // 
            // comboBoxHeaderCase
            // 
            this.comboBoxHeaderCase.FormattingEnabled = true;
            this.comboBoxHeaderCase.Location = new System.Drawing.Point(165, 4);
            this.comboBoxHeaderCase.Name = "comboBoxHeaderCase";
            this.comboBoxHeaderCase.Size = new System.Drawing.Size(94, 23);
            this.comboBoxHeaderCase.TabIndex = 14;
            // 
            // btnProcessRenameColumns
            // 
            this.btnProcessRenameColumns.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnProcessRenameColumns.Location = new System.Drawing.Point(743, 7);
            this.btnProcessRenameColumns.Name = "btnProcessRenameColumns";
            this.btnProcessRenameColumns.Size = new System.Drawing.Size(75, 23);
            this.btnProcessRenameColumns.TabIndex = 9;
            this.btnProcessRenameColumns.Text = "Process";
            this.btnProcessRenameColumns.UseVisualStyleBackColor = true;
            this.btnProcessRenameColumns.Click += new System.EventHandler(this.btnProcessRenameColumns_Click);
            // 
            // dgvRenameColumns
            // 
            this.dgvRenameColumns.AllowUserToDeleteRows = false;
            this.dgvRenameColumns.AllowUserToResizeRows = false;
            this.dgvRenameColumns.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dgvRenameColumns.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Red;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRenameColumns.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvRenameColumns.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRenameColumns.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvRenameColumns.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRenameColumns.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvRenameColumns.Location = new System.Drawing.Point(3, 3);
            this.dgvRenameColumns.MultiSelect = false;
            this.dgvRenameColumns.Name = "dgvRenameColumns";
            this.dgvRenameColumns.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRenameColumns.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvRenameColumns.RowHeadersVisible = false;
            this.dgvRenameColumns.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvRenameColumns.Size = new System.Drawing.Size(902, 224);
            this.dgvRenameColumns.TabIndex = 0;
            // 
            // tabPageChangeCases
            // 
            this.tabPageChangeCases.Controls.Add(this.tableLayoutPanel5);
            this.tabPageChangeCases.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageChangeCases.Location = new System.Drawing.Point(4, 24);
            this.tabPageChangeCases.Name = "tabPageChangeCases";
            this.tabPageChangeCases.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageChangeCases.Size = new System.Drawing.Size(914, 279);
            this.tabPageChangeCases.TabIndex = 1;
            this.tabPageChangeCases.Text = "Change cases";
            this.tabPageChangeCases.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Controls.Add(this.panel9, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.dgvChangeCases, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel5.Size = new System.Drawing.Size(908, 273);
            this.tableLayoutPanel5.TabIndex = 15;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.tableLayoutPanel3);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(3, 242);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(902, 28);
            this.panel9.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 4;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.chkBoxChoosecaseSelectAll, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnCancelChangeCases, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.cmbBoxChoosecaseSelectAll, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.btnProcessChangeCases, 2, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(902, 28);
            this.tableLayoutPanel3.TabIndex = 15;
            // 
            // chkBoxChoosecaseSelectAll
            // 
            this.chkBoxChoosecaseSelectAll.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chkBoxChoosecaseSelectAll.AutoSize = true;
            this.chkBoxChoosecaseSelectAll.Location = new System.Drawing.Point(3, 7);
            this.chkBoxChoosecaseSelectAll.Name = "chkBoxChoosecaseSelectAll";
            this.chkBoxChoosecaseSelectAll.Size = new System.Drawing.Size(15, 14);
            this.chkBoxChoosecaseSelectAll.TabIndex = 13;
            this.chkBoxChoosecaseSelectAll.UseVisualStyleBackColor = true;
            this.chkBoxChoosecaseSelectAll.Click += new System.EventHandler(this.chkBoxChoosecaseSelectAll_Click);
            // 
            // btnCancelChangeCases
            // 
            this.btnCancelChangeCases.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnCancelChangeCases.Location = new System.Drawing.Point(824, 3);
            this.btnCancelChangeCases.Name = "btnCancelChangeCases";
            this.btnCancelChangeCases.Size = new System.Drawing.Size(75, 22);
            this.btnCancelChangeCases.TabIndex = 12;
            this.btnCancelChangeCases.Text = "Cancel";
            this.btnCancelChangeCases.UseVisualStyleBackColor = true;
            this.btnCancelChangeCases.Click += new System.EventHandler(this.btnCancelChangeCases_Click);
            // 
            // cmbBoxChoosecaseSelectAll
            // 
            this.cmbBoxChoosecaseSelectAll.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cmbBoxChoosecaseSelectAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbBoxChoosecaseSelectAll.FormattingEnabled = true;
            this.cmbBoxChoosecaseSelectAll.Location = new System.Drawing.Point(24, 3);
            this.cmbBoxChoosecaseSelectAll.Name = "cmbBoxChoosecaseSelectAll";
            this.cmbBoxChoosecaseSelectAll.Size = new System.Drawing.Size(121, 23);
            this.cmbBoxChoosecaseSelectAll.TabIndex = 14;
            this.cmbBoxChoosecaseSelectAll.SelectedIndexChanged += new System.EventHandler(this.cmbBoxChoosecaseSelectAll_SelectedIndexChanged);
            // 
            // btnProcessChangeCases
            // 
            this.btnProcessChangeCases.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnProcessChangeCases.Location = new System.Drawing.Point(743, 3);
            this.btnProcessChangeCases.Name = "btnProcessChangeCases";
            this.btnProcessChangeCases.Size = new System.Drawing.Size(75, 22);
            this.btnProcessChangeCases.TabIndex = 11;
            this.btnProcessChangeCases.Text = "Process";
            this.btnProcessChangeCases.UseVisualStyleBackColor = true;
            this.btnProcessChangeCases.Click += new System.EventHandler(this.btnProcessChangeCases_Click);
            // 
            // dgvChangeCases
            // 
            this.dgvChangeCases.AllowUserToDeleteRows = false;
            this.dgvChangeCases.AllowUserToResizeRows = false;
            this.dgvChangeCases.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dgvChangeCases.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.Red;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvChangeCases.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvChangeCases.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvChangeCases.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvChangeCases.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvChangeCases.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvChangeCases.Location = new System.Drawing.Point(3, 3);
            this.dgvChangeCases.MultiSelect = false;
            this.dgvChangeCases.Name = "dgvChangeCases";
            this.dgvChangeCases.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvChangeCases.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvChangeCases.RowHeadersVisible = false;
            this.dgvChangeCases.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvChangeCases.Size = new System.Drawing.Size(902, 233);
            this.dgvChangeCases.TabIndex = 5;
            this.dgvChangeCases.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvChangeCases_CellContentClick);
            // 
            // tabPageChangeDateFormat
            // 
            this.tabPageChangeDateFormat.Controls.Add(this.tableLayoutPanel6);
            this.tabPageChangeDateFormat.Location = new System.Drawing.Point(4, 24);
            this.tabPageChangeDateFormat.Name = "tabPageChangeDateFormat";
            this.tabPageChangeDateFormat.Size = new System.Drawing.Size(914, 279);
            this.tabPageChangeDateFormat.TabIndex = 2;
            this.tabPageChangeDateFormat.Text = "Change date format";
            this.tabPageChangeDateFormat.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Controls.Add(this.panel10, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.dgvChangeDateFormat, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel6.Size = new System.Drawing.Size(914, 279);
            this.tableLayoutPanel6.TabIndex = 20;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.tableLayoutPanel9);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(3, 245);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(908, 31);
            this.panel10.TabIndex = 0;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 4;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel9.Controls.Add(this.chkBoxChooseDateFormatSelectAll, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.btnCancelChooseDateFormat, 3, 0);
            this.tableLayoutPanel9.Controls.Add(this.btnProcessChangeDateFormat, 2, 0);
            this.tableLayoutPanel9.Controls.Add(this.cmbBoxChooseDateFormatSelectAll, 1, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(908, 31);
            this.tableLayoutPanel9.TabIndex = 20;
            // 
            // chkBoxChooseDateFormatSelectAll
            // 
            this.chkBoxChooseDateFormatSelectAll.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chkBoxChooseDateFormatSelectAll.AutoSize = true;
            this.chkBoxChooseDateFormatSelectAll.Location = new System.Drawing.Point(3, 8);
            this.chkBoxChooseDateFormatSelectAll.Name = "chkBoxChooseDateFormatSelectAll";
            this.chkBoxChooseDateFormatSelectAll.Size = new System.Drawing.Size(15, 14);
            this.chkBoxChooseDateFormatSelectAll.TabIndex = 18;
            this.chkBoxChooseDateFormatSelectAll.UseVisualStyleBackColor = true;
            this.chkBoxChooseDateFormatSelectAll.Click += new System.EventHandler(this.chkBoxChooseDateFormatSelectAll_Click);
            // 
            // btnCancelChooseDateFormat
            // 
            this.btnCancelChooseDateFormat.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnCancelChooseDateFormat.Location = new System.Drawing.Point(830, 4);
            this.btnCancelChooseDateFormat.Name = "btnCancelChooseDateFormat";
            this.btnCancelChooseDateFormat.Size = new System.Drawing.Size(75, 23);
            this.btnCancelChooseDateFormat.TabIndex = 17;
            this.btnCancelChooseDateFormat.Text = "Cancel";
            this.btnCancelChooseDateFormat.UseVisualStyleBackColor = true;
            this.btnCancelChooseDateFormat.Click += new System.EventHandler(this.btnCancelChooseDateFormat_Click);
            // 
            // btnProcessChangeDateFormat
            // 
            this.btnProcessChangeDateFormat.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnProcessChangeDateFormat.Location = new System.Drawing.Point(749, 4);
            this.btnProcessChangeDateFormat.Name = "btnProcessChangeDateFormat";
            this.btnProcessChangeDateFormat.Size = new System.Drawing.Size(75, 23);
            this.btnProcessChangeDateFormat.TabIndex = 16;
            this.btnProcessChangeDateFormat.Text = "Process";
            this.btnProcessChangeDateFormat.UseVisualStyleBackColor = true;
            this.btnProcessChangeDateFormat.Click += new System.EventHandler(this.btnProcessChangeDateFormat_Click);
            // 
            // cmbBoxChooseDateFormatSelectAll
            // 
            this.cmbBoxChooseDateFormatSelectAll.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.cmbBoxChooseDateFormatSelectAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbBoxChooseDateFormatSelectAll.FormattingEnabled = true;
            this.cmbBoxChooseDateFormatSelectAll.Location = new System.Drawing.Point(24, 4);
            this.cmbBoxChooseDateFormatSelectAll.Name = "cmbBoxChooseDateFormatSelectAll";
            this.cmbBoxChooseDateFormatSelectAll.Size = new System.Drawing.Size(121, 23);
            this.cmbBoxChooseDateFormatSelectAll.TabIndex = 19;
            this.cmbBoxChooseDateFormatSelectAll.SelectedIndexChanged += new System.EventHandler(this.cmbBoxChooseDateFormatSelectAll_SelectedIndexChanged);
            // 
            // dgvChangeDateFormat
            // 
            this.dgvChangeDateFormat.AllowUserToDeleteRows = false;
            this.dgvChangeDateFormat.AllowUserToResizeRows = false;
            this.dgvChangeDateFormat.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dgvChangeDateFormat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.Red;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvChangeDateFormat.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvChangeDateFormat.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvChangeDateFormat.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgvChangeDateFormat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvChangeDateFormat.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvChangeDateFormat.Location = new System.Drawing.Point(3, 3);
            this.dgvChangeDateFormat.MultiSelect = false;
            this.dgvChangeDateFormat.Name = "dgvChangeDateFormat";
            this.dgvChangeDateFormat.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvChangeDateFormat.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvChangeDateFormat.RowHeadersVisible = false;
            this.dgvChangeDateFormat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvChangeDateFormat.Size = new System.Drawing.Size(908, 236);
            this.dgvChangeDateFormat.TabIndex = 15;
            this.dgvChangeDateFormat.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvChangeDateFormat_CellContentClick);
            // 
            // tabPageReplaceValues
            // 
            this.tabPageReplaceValues.Controls.Add(this.tableLayoutPanel7);
            this.tabPageReplaceValues.Location = new System.Drawing.Point(4, 24);
            this.tabPageReplaceValues.Name = "tabPageReplaceValues";
            this.tabPageReplaceValues.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageReplaceValues.Size = new System.Drawing.Size(914, 279);
            this.tabPageReplaceValues.TabIndex = 3;
            this.tabPageReplaceValues.Text = "Replace values";
            this.tabPageReplaceValues.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 1;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Controls.Add(this.panel11, 0, 1);
            this.tableLayoutPanel7.Controls.Add(this.dgvReplaceValue, 0, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 2;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel7.Size = new System.Drawing.Size(908, 273);
            this.tableLayoutPanel7.TabIndex = 21;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.tableLayoutPanel10);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(3, 241);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(902, 29);
            this.panel11.TabIndex = 0;
            // 
            // tableLayoutPanel10
            // 
            this.tableLayoutPanel10.ColumnCount = 2;
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel10.Controls.Add(this.btnProcessReplaceValues, 0, 0);
            this.tableLayoutPanel10.Controls.Add(this.btnCancelReplaceValues, 1, 0);
            this.tableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel10.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel10.Name = "tableLayoutPanel10";
            this.tableLayoutPanel10.RowCount = 1;
            this.tableLayoutPanel10.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel10.Size = new System.Drawing.Size(902, 29);
            this.tableLayoutPanel10.TabIndex = 20;
            // 
            // btnProcessReplaceValues
            // 
            this.btnProcessReplaceValues.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnProcessReplaceValues.Location = new System.Drawing.Point(743, 3);
            this.btnProcessReplaceValues.Name = "btnProcessReplaceValues";
            this.btnProcessReplaceValues.Size = new System.Drawing.Size(75, 23);
            this.btnProcessReplaceValues.TabIndex = 18;
            this.btnProcessReplaceValues.Text = "Process";
            this.btnProcessReplaceValues.UseVisualStyleBackColor = true;
            this.btnProcessReplaceValues.Click += new System.EventHandler(this.btnProcessReplaceValues_Click);
            // 
            // btnCancelReplaceValues
            // 
            this.btnCancelReplaceValues.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnCancelReplaceValues.Location = new System.Drawing.Point(824, 3);
            this.btnCancelReplaceValues.Name = "btnCancelReplaceValues";
            this.btnCancelReplaceValues.Size = new System.Drawing.Size(75, 23);
            this.btnCancelReplaceValues.TabIndex = 19;
            this.btnCancelReplaceValues.Text = "Cancel";
            this.btnCancelReplaceValues.UseVisualStyleBackColor = true;
            this.btnCancelReplaceValues.Click += new System.EventHandler(this.btnCancelReplaceValues_Click);
            // 
            // dgvReplaceValue
            // 
            this.dgvReplaceValue.AllowUserToDeleteRows = false;
            this.dgvReplaceValue.AllowUserToResizeRows = false;
            this.dgvReplaceValue.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dgvReplaceValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.Red;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReplaceValue.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvReplaceValue.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvReplaceValue.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgvReplaceValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvReplaceValue.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvReplaceValue.Location = new System.Drawing.Point(3, 3);
            this.dgvReplaceValue.MultiSelect = false;
            this.dgvReplaceValue.Name = "dgvReplaceValue";
            this.dgvReplaceValue.ReadOnly = true;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvReplaceValue.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvReplaceValue.RowHeadersVisible = false;
            this.dgvReplaceValue.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvReplaceValue.Size = new System.Drawing.Size(902, 232);
            this.dgvReplaceValue.TabIndex = 20;
            this.dgvReplaceValue.DefaultValuesNeeded += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgvReplaceValue_DefaultValuesNeeded);
            // 
            // tabPageRemoveWhiteSpaces
            // 
            this.tabPageRemoveWhiteSpaces.Controls.Add(this.tableLayoutPanel8);
            this.tabPageRemoveWhiteSpaces.Location = new System.Drawing.Point(4, 24);
            this.tabPageRemoveWhiteSpaces.Name = "tabPageRemoveWhiteSpaces";
            this.tabPageRemoveWhiteSpaces.Size = new System.Drawing.Size(914, 279);
            this.tabPageRemoveWhiteSpaces.TabIndex = 4;
            this.tabPageRemoveWhiteSpaces.Text = "Remove white spaces";
            this.tabPageRemoveWhiteSpaces.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Controls.Add(this.panel12, 0, 1);
            this.tableLayoutPanel8.Controls.Add(this.dgvRemoveWhiteSpaces, 0, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel8.Size = new System.Drawing.Size(914, 279);
            this.tableLayoutPanel8.TabIndex = 22;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.tableLayoutPanel11);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(3, 244);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(908, 32);
            this.panel12.TabIndex = 0;
            // 
            // tableLayoutPanel11
            // 
            this.tableLayoutPanel11.ColumnCount = 3;
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel11.Controls.Add(this.chkBoxRemoveWhiteSpacesSelectAll, 0, 0);
            this.tableLayoutPanel11.Controls.Add(this.btnCancelRemoveWhiteSpaces, 2, 0);
            this.tableLayoutPanel11.Controls.Add(this.btnProcessRemoveWhiteSpaces, 1, 0);
            this.tableLayoutPanel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel11.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel11.Name = "tableLayoutPanel11";
            this.tableLayoutPanel11.RowCount = 1;
            this.tableLayoutPanel11.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel11.Size = new System.Drawing.Size(908, 32);
            this.tableLayoutPanel11.TabIndex = 13;
            // 
            // chkBoxRemoveWhiteSpacesSelectAll
            // 
            this.chkBoxRemoveWhiteSpacesSelectAll.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.chkBoxRemoveWhiteSpacesSelectAll.AutoSize = true;
            this.chkBoxRemoveWhiteSpacesSelectAll.Location = new System.Drawing.Point(3, 9);
            this.chkBoxRemoveWhiteSpacesSelectAll.Name = "chkBoxRemoveWhiteSpacesSelectAll";
            this.chkBoxRemoveWhiteSpacesSelectAll.Size = new System.Drawing.Size(15, 14);
            this.chkBoxRemoveWhiteSpacesSelectAll.TabIndex = 10;
            this.chkBoxRemoveWhiteSpacesSelectAll.UseVisualStyleBackColor = true;
            this.chkBoxRemoveWhiteSpacesSelectAll.Click += new System.EventHandler(this.chkBoxRemoveWhiteSpacesSelectAll_Click);
            // 
            // btnCancelRemoveWhiteSpaces
            // 
            this.btnCancelRemoveWhiteSpaces.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.btnCancelRemoveWhiteSpaces.Location = new System.Drawing.Point(830, 3);
            this.btnCancelRemoveWhiteSpaces.Name = "btnCancelRemoveWhiteSpaces";
            this.btnCancelRemoveWhiteSpaces.Size = new System.Drawing.Size(75, 26);
            this.btnCancelRemoveWhiteSpaces.TabIndex = 12;
            this.btnCancelRemoveWhiteSpaces.Text = "Cancel";
            this.btnCancelRemoveWhiteSpaces.UseVisualStyleBackColor = true;
            this.btnCancelRemoveWhiteSpaces.Click += new System.EventHandler(this.btnCancelRemoveWhiteSpaces_Click);
            // 
            // btnProcessRemoveWhiteSpaces
            // 
            this.btnProcessRemoveWhiteSpaces.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.btnProcessRemoveWhiteSpaces.Location = new System.Drawing.Point(749, 3);
            this.btnProcessRemoveWhiteSpaces.Name = "btnProcessRemoveWhiteSpaces";
            this.btnProcessRemoveWhiteSpaces.Size = new System.Drawing.Size(75, 25);
            this.btnProcessRemoveWhiteSpaces.TabIndex = 11;
            this.btnProcessRemoveWhiteSpaces.Text = "Process";
            this.btnProcessRemoveWhiteSpaces.UseVisualStyleBackColor = true;
            this.btnProcessRemoveWhiteSpaces.Click += new System.EventHandler(this.btnProcessRemoveWhiteSpaces_Click);
            // 
            // dgvRemoveWhiteSpaces
            // 
            this.dgvRemoveWhiteSpaces.AllowUserToDeleteRows = false;
            this.dgvRemoveWhiteSpaces.AllowUserToResizeRows = false;
            this.dgvRemoveWhiteSpaces.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.dgvRemoveWhiteSpaces.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.Red;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRemoveWhiteSpaces.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvRemoveWhiteSpaces.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRemoveWhiteSpaces.DefaultCellStyle = dataGridViewCellStyle17;
            this.dgvRemoveWhiteSpaces.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRemoveWhiteSpaces.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.dgvRemoveWhiteSpaces.Location = new System.Drawing.Point(3, 3);
            this.dgvRemoveWhiteSpaces.MultiSelect = false;
            this.dgvRemoveWhiteSpaces.Name = "dgvRemoveWhiteSpaces";
            this.dgvRemoveWhiteSpaces.ReadOnly = true;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRemoveWhiteSpaces.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dgvRemoveWhiteSpaces.RowHeadersVisible = false;
            this.dgvRemoveWhiteSpaces.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvRemoveWhiteSpaces.Size = new System.Drawing.Size(908, 235);
            this.dgvRemoveWhiteSpaces.TabIndex = 7;
            this.dgvRemoveWhiteSpaces.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRemoveWhiteSpaces_CellContentClick);
            // 
            // tabPageOutputFields
            // 
            this.tabPageOutputFields.Location = new System.Drawing.Point(4, 24);
            this.tabPageOutputFields.Name = "tabPageOutputFields";
            this.tabPageOutputFields.Size = new System.Drawing.Size(914, 279);
            this.tabPageOutputFields.TabIndex = 5;
            this.tabPageOutputFields.Text = "Output fields";
            this.tabPageOutputFields.UseVisualStyleBackColor = true;
            // 
            // btnPreviewData
            // 
            this.btnPreviewData.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnPreviewData.Location = new System.Drawing.Point(3, 3);
            this.btnPreviewData.Name = "btnPreviewData";
            this.btnPreviewData.Size = new System.Drawing.Size(278, 29);
            this.btnPreviewData.TabIndex = 8;
            this.btnPreviewData.Text = "Preview Data && Export Data";
            this.btnPreviewData.UseVisualStyleBackColor = true;
            this.btnPreviewData.Click += new System.EventHandler(this.btnPreviewData_Click);
            // 
            // txtFileName
            // 
            this.txtFileName.BackColor = System.Drawing.SystemColors.Control;
            this.txtFileName.Location = new System.Drawing.Point(68, 4);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.ReadOnly = true;
            this.txtFileName.Size = new System.Drawing.Size(327, 22);
            this.txtFileName.TabIndex = 14;
            // 
            // chkBoxEnableSourceColumnsTab
            // 
            this.chkBoxEnableSourceColumnsTab.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.chkBoxEnableSourceColumnsTab.AutoSize = true;
            this.chkBoxEnableSourceColumnsTab.Location = new System.Drawing.Point(3, 5);
            this.chkBoxEnableSourceColumnsTab.Name = "chkBoxEnableSourceColumnsTab";
            this.chkBoxEnableSourceColumnsTab.Size = new System.Drawing.Size(375, 18);
            this.chkBoxEnableSourceColumnsTab.TabIndex = 16;
            this.chkBoxEnableSourceColumnsTab.Text = "Enable Source Fields tab";
            this.chkBoxEnableSourceColumnsTab.UseVisualStyleBackColor = true;
            this.chkBoxEnableSourceColumnsTab.Click += new System.EventHandler(this.chkBoxEnableSourceColumnsTab_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.dgvShowDetails);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(8, 8);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(918, 162);
            this.panel1.TabIndex = 18;
            // 
            // dgvShowDetails
            // 
            this.dgvShowDetails.AllowUserToResizeColumns = false;
            this.dgvShowDetails.AllowUserToResizeRows = false;
            this.dgvShowDetails.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvShowDetails.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvShowDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvShowDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvShowDetails.Location = new System.Drawing.Point(0, 0);
            this.dgvShowDetails.Margin = new System.Windows.Forms.Padding(0);
            this.dgvShowDetails.Name = "dgvShowDetails";
            this.dgvShowDetails.ReadOnly = true;
            this.dgvShowDetails.RowHeadersVisible = false;
            this.dgvShowDetails.Size = new System.Drawing.Size(916, 160);
            this.dgvShowDetails.TabIndex = 19;
            // 
            // comboBoxDataExportFileType
            // 
            this.comboBoxDataExportFileType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.comboBoxDataExportFileType.FormattingEnabled = true;
            this.comboBoxDataExportFileType.Location = new System.Drawing.Point(3, 393);
            this.comboBoxDataExportFileType.Name = "comboBoxDataExportFileType";
            this.comboBoxDataExportFileType.Size = new System.Drawing.Size(278, 22);
            this.comboBoxDataExportFileType.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 45);
            this.label4.Margin = new System.Windows.Forms.Padding(3, 10, 3, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 15);
            this.label4.TabIndex = 23;
            this.label4.Text = "Applied steps";
            // 
            // dgvStepsDone
            // 
            this.dgvStepsDone.AllowUserToAddRows = false;
            this.dgvStepsDone.AllowUserToDeleteRows = false;
            this.dgvStepsDone.AllowUserToResizeColumns = false;
            this.dgvStepsDone.AllowUserToResizeRows = false;
            this.dgvStepsDone.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvStepsDone.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvStepsDone.ColumnHeadersVisible = false;
            this.dgvStepsDone.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.Desktop;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvStepsDone.DefaultCellStyle = dataGridViewCellStyle19;
            this.dgvStepsDone.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvStepsDone.Location = new System.Drawing.Point(3, 68);
            this.dgvStepsDone.MultiSelect = false;
            this.dgvStepsDone.Name = "dgvStepsDone";
            this.dgvStepsDone.ReadOnly = true;
            this.dgvStepsDone.RowHeadersVisible = false;
            this.dgvStepsDone.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvStepsDone.Size = new System.Drawing.Size(278, 279);
            this.dgvStepsDone.TabIndex = 21;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 370);
            this.label3.Margin = new System.Windows.Forms.Padding(3, 20, 3, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 15);
            this.label3.TabIndex = 20;
            this.label3.Text = "Choose file type";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 15);
            this.label2.TabIndex = 21;
            this.label2.Text = "File name";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.settingsToolStripMenuItem,
            this.automateToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1224, 24);
            this.menuStrip1.TabIndex = 22;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // automateToolStripMenuItem
            // 
            this.automateToolStripMenuItem.Name = "automateToolStripMenuItem";
            this.automateToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.automateToolStripMenuItem.Text = "Automation";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(111, 222);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(428, 10);
            this.progressBar.TabIndex = 23;
            // 
            // lblDimension
            // 
            this.lblDimension.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDimension.Location = new System.Drawing.Point(384, 7);
            this.lblDimension.Name = "lblDimension";
            this.lblDimension.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblDimension.Size = new System.Drawing.Size(541, 14);
            this.lblDimension.TabIndex = 24;
            this.lblDimension.Text = "Dimension";
            this.lblDimension.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.txtFileName);
            this.panel3.Controls.Add(this.btnImportCsvFile);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(928, 33);
            this.panel3.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tableMiddleBlock);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 42);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(928, 341);
            this.panel4.TabIndex = 21;
            // 
            // tableMiddleBlock
            // 
            this.tableMiddleBlock.ColumnCount = 2;
            this.tableMiddleBlock.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 41.15479F));
            this.tableMiddleBlock.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 58.84521F));
            this.tableMiddleBlock.Controls.Add(this.chkBoxEnableSourceColumnsTab, 0, 0);
            this.tableMiddleBlock.Controls.Add(this.tabControl, 0, 1);
            this.tableMiddleBlock.Controls.Add(this.lblDimension, 1, 0);
            this.tableMiddleBlock.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableMiddleBlock.Location = new System.Drawing.Point(0, 0);
            this.tableMiddleBlock.Name = "tableMiddleBlock";
            this.tableMiddleBlock.RowCount = 2;
            this.tableMiddleBlock.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.387096F));
            this.tableMiddleBlock.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 91.6129F));
            this.tableMiddleBlock.Size = new System.Drawing.Size(928, 341);
            this.tableMiddleBlock.TabIndex = 25;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.Controls.Add(this.progressBar);
            this.panel5.Controls.Add(this.panel1);
            this.panel5.Location = new System.Drawing.Point(0, 386);
            this.panel5.Margin = new System.Windows.Forms.Padding(0);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(8);
            this.panel5.Size = new System.Drawing.Size(934, 178);
            this.panel5.TabIndex = 22;
            // 
            // tableLeftBlock
            // 
            this.tableLeftBlock.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLeftBlock.ColumnCount = 2;
            this.tableLeftBlock.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLeftBlock.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 290F));
            this.tableLeftBlock.Controls.Add(this.panel4, 0, 1);
            this.tableLeftBlock.Controls.Add(this.panel3, 0, 0);
            this.tableLeftBlock.Controls.Add(this.panel5, 0, 2);
            this.tableLeftBlock.Controls.Add(this.panelRightBlock, 1, 0);
            this.tableLeftBlock.Controls.Add(this.label5, 0, 3);
            this.tableLeftBlock.Location = new System.Drawing.Point(0, 24);
            this.tableLeftBlock.Name = "tableLeftBlock";
            this.tableLeftBlock.RowCount = 4;
            this.tableLeftBlock.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLeftBlock.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLeftBlock.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLeftBlock.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLeftBlock.Size = new System.Drawing.Size(1224, 593);
            this.tableLeftBlock.TabIndex = 27;
            // 
            // panelRightBlock
            // 
            this.panelRightBlock.Controls.Add(this.tableRightBlock);
            this.panelRightBlock.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelRightBlock.Location = new System.Drawing.Point(937, 3);
            this.panelRightBlock.Name = "panelRightBlock";
            this.tableLeftBlock.SetRowSpan(this.panelRightBlock, 3);
            this.panelRightBlock.Size = new System.Drawing.Size(284, 558);
            this.panelRightBlock.TabIndex = 25;
            // 
            // tableRightBlock
            // 
            this.tableRightBlock.ColumnCount = 1;
            this.tableRightBlock.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableRightBlock.Controls.Add(this.btnExportToCsv, 0, 5);
            this.tableRightBlock.Controls.Add(this.btnPreviewData, 0, 0);
            this.tableRightBlock.Controls.Add(this.comboBoxDataExportFileType, 0, 4);
            this.tableRightBlock.Controls.Add(this.label3, 0, 3);
            this.tableRightBlock.Controls.Add(this.dgvStepsDone, 0, 2);
            this.tableRightBlock.Controls.Add(this.label4, 0, 1);
            this.tableRightBlock.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableRightBlock.Location = new System.Drawing.Point(0, 0);
            this.tableRightBlock.Name = "tableRightBlock";
            this.tableRightBlock.RowCount = 7;
            this.tableRightBlock.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableRightBlock.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableRightBlock.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableRightBlock.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableRightBlock.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableRightBlock.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableRightBlock.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableRightBlock.Size = new System.Drawing.Size(284, 558);
            this.tableRightBlock.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.tableLeftBlock.SetColumnSpan(this.label5, 2);
            this.label5.Dock = System.Windows.Forms.DockStyle.Left;
            this.label5.Location = new System.Drawing.Point(5, 569);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 5, 5, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 14);
            this.label5.TabIndex = 26;
            this.label5.Text = "Ezy data Tools";
            // 
            // Column1
            // 
            this.Column1.FillWeight = 20F;
            this.Column1.HeaderText = "";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Column1.Width = 20;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "Column2";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1224, 617);
            this.Controls.Add(this.tableLeftBlock);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Corbel", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ezy Data Tool ™";
            this.SizeChanged += new System.EventHandler(this.frmMain_SizeChanged);
            this.tabControl.ResumeLayout(false);
            this.tabPageSourceColumns.ResumeLayout(false);
            this.tblSC.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSOurceColumns)).EndInit();
            this.tabPageRenameColumns.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRenameColumns)).EndInit();
            this.tabPageChangeCases.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChangeCases)).EndInit();
            this.tabPageChangeDateFormat.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChangeDateFormat)).EndInit();
            this.tabPageReplaceValues.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.tableLayoutPanel10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvReplaceValue)).EndInit();
            this.tabPageRemoveWhiteSpaces.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.tableLayoutPanel11.ResumeLayout(false);
            this.tableLayoutPanel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRemoveWhiteSpaces)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvShowDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStepsDone)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.tableMiddleBlock.ResumeLayout(false);
            this.tableMiddleBlock.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.tableLeftBlock.ResumeLayout(false);
            this.tableLeftBlock.PerformLayout();
            this.panelRightBlock.ResumeLayout(false);
            this.tableRightBlock.ResumeLayout(false);
            this.tableRightBlock.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnImportCsvFile;
        private System.Windows.Forms.Button btnExportToCsv;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPageRenameColumns;
        private System.Windows.Forms.TabPage tabPageChangeCases;
        private System.Windows.Forms.DataGridView dgvRenameColumns;
        private System.Windows.Forms.TabPage tabPageReplaceValues;
        private System.Windows.Forms.Button btnPreviewData;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.TabPage tabPageChangeDateFormat;
        private System.Windows.Forms.TabPage tabPageRemoveWhiteSpaces;
        private System.Windows.Forms.TabPage tabPageOutputFields;
        private System.Windows.Forms.TabPage tabPageSourceColumns;
        private System.Windows.Forms.DataGridView dgvSOurceColumns;
        private System.Windows.Forms.Button btnCancelSourceColumns;
        private System.Windows.Forms.Button btnProcessSourceColumns;
        private System.Windows.Forms.CheckBox chkBoxSourceColumnsSelectAll;
        private System.Windows.Forms.Button btnCancelRenameColumns;
        private System.Windows.Forms.Button btnProcessRenameColumns;
        private System.Windows.Forms.CheckBox chkBoxEnableSourceColumnsTab;
        private System.Windows.Forms.DataGridView dgvChangeCases;
        private System.Windows.Forms.Button btnCancelChangeCases;
        private System.Windows.Forms.Button btnProcessChangeCases;
        private System.Windows.Forms.CheckBox chkBoxChoosecaseSelectAll;
        private System.Windows.Forms.ComboBox cmbBoxChoosecaseSelectAll;
        private System.Windows.Forms.ComboBox cmbBoxChooseDateFormatSelectAll;
        private System.Windows.Forms.CheckBox chkBoxChooseDateFormatSelectAll;
        private System.Windows.Forms.Button btnCancelChooseDateFormat;
        private System.Windows.Forms.Button btnProcessChangeDateFormat;
        private System.Windows.Forms.DataGridView dgvChangeDateFormat;
        private System.Windows.Forms.Button btnCancelReplaceValues;
        private System.Windows.Forms.Button btnProcessReplaceValues;
        private System.Windows.Forms.DataGridView dgvRemoveWhiteSpaces;
        private System.Windows.Forms.CheckBox chkBoxRemoveWhiteSpacesSelectAll;
        private System.Windows.Forms.Button btnCancelRemoveWhiteSpaces;
        private System.Windows.Forms.Button btnProcessRemoveWhiteSpaces;
        private System.Windows.Forms.DataGridView dgvReplaceValue;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxHeaderCase;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBoxDataExportFileType;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgvStepsDone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ToolStripMenuItem automateToolStripMenuItem;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.DataGridView dgvShowDetails;
        private System.Windows.Forms.Label lblDimension;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TableLayoutPanel tableMiddleBlock;
        private System.Windows.Forms.TableLayoutPanel tblSC;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TableLayoutPanel tableLeftBlock;
        private System.Windows.Forms.Panel panelRightBlock;
        private System.Windows.Forms.TableLayoutPanel tableRightBlock;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel10;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel11;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewImageColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
    }
}

