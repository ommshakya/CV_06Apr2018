﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Oms.TinyEtl
{
    //http://www.c-sharpcorner.com/uploadfile/scottlysle/working-with-delimited-text-files-in-C-Sharp/
    public partial class frmCsvExplorer : Form
    {
        public frmCsvExplorer()
        {
            InitializeComponent();
        }
        public void GetCount(string fileName)
        {
            String connect = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\"" +
                Path.GetDirectoryName(fileName) + "\";Extended Properties='text;HDR=yes;FMT=Delimited(,)';";// "Provider=Microsoft.JET.OLEDB.4.0;data source=.\\Employee.mdb";
            OleDbConnection con = new OleDbConnection(connect);
            con.Open();
            Console.WriteLine("Made the connection to the database");

            OleDbCommand command = con.CreateCommand();
            //command.CommandText = string.Format("SELECT COUNT(*) FROM [{0}]", new FileInfo(fileName).Name);// "SELECT COUNT(*) FROM Employee";
            //int i =  (int)command.ExecuteScalar();
            //con.Close();

            //command.CommandText = string.Format("SELECT AVG(SKU_ID) FROM [{0}]", new FileInfo(fileName).Name);// "SELECT COUNT(*) FROM Employee";
            //object i = (object)command.ExecuteScalar();
            //con.Close();


            command.CommandText = string.Format("SELECT LOWER([SECT_NAME]) [LOWERCS] FROM [{0}]", new FileInfo(fileName).Name);// "SELECT COUNT(*) FROM Employee";
            OleDbDataReader reader;
            reader = command.ExecuteReader();
            while (reader.Read())
            {
                string str = reader.GetValue(0).ToString();
                MessageBox.Show(str);
            }
            reader.Close();
            command.Dispose();
            con.Close();
        }
        public DataTable ReadCsv(string fileName)
        {
            DataTable dt = new DataTable();
            using (OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\"" +
                Path.GetDirectoryName(fileName) + "\";Extended Properties='text;HDR=yes;FMT=Delimited(,)';"))
            {
                using (OleDbCommand cmd = new OleDbCommand(string.Format("SELECT SKU_ID, SECT_NAME FROM [{0}]", new FileInfo(fileName).Name), con))
                {
                    con.Open();
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                    {
                        adapter.Fill(dt);

                    }
                }
            }
            return dt;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "CSV|*.csv", ValidateNames = true, Multiselect = false })
                //{
                //    if (ofd.ShowDialog() == DialogResult.OK)
                //        //dataGridView1.DataSource = ReadCsv(ofd.FileName);
                //        GetCount(ofd.FileName);
                //}

                ConnectLocalDb();

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Message",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            //string strConn = @"Driver={Microsoft Text Driver (*.txt; *.csv)};Dbq=C:;Extensions=csv,txt";
            
            //OdbcConnection objCSV = new OdbcConnection(strConn);
            //objCSV.Open();

            //OdbcCommand oCmd = new OdbcCommand("select column1,column2 from THECSVFILE.CSV", objCSV);
            ////OdbcDataReader oDR = oCmd.ExecuteReader();

            ////while (oDR.Read())
            ////{
            ////    // Do something
            ////}

            //OdbcDataAdapter da = new OdbcDataAdapter(oCmd);
            //DataTable dt = new DataTable();
            //da.Fill(dt);

            //string name = dt.Rows.Count.ToString();
            //int i = dt.Columns.Count;

        }

        private void ConnectLocalDb()
        {
            //https://us3.proxysite.com/process.php?d=x5B99FmPCRZLiN7LQFXWwMdJOjQXi39xppqhnXuurMu3A1asR3ti&b=1
            SqlConnection sqlConnection1 = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\z.Oms\VisualStudioApps\Oms.TinyEtl\Oms.TinyEtl\TinyToolDb.mdf;Integrated Security = True;");
            SqlCommand cmd = new SqlCommand();
            SqlDataReader reader;

            cmd.CommandText = "SELECT * FROM TBL";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = sqlConnection1;

            sqlConnection1.Open();

            //reader = cmd.ExecuteReader();
            // Data is accessible through the DataReader object here.

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            sqlConnection1.Close();
        }
    }
}


//Data Source = (LocalDB)\MSSQLLocalDB;AttachDbFilename=D:\z.Oms\VisualStudioApps\Oms.TinyEtl\Oms.TinyEtl\TinyToolDb.mdf;Integrated Security = True
    //@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=database;AttachDbFilename=C:\Desarrollo\database.mdf;Integrated Security=True";