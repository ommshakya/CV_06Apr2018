﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;


namespace Oms.TinyEtl
{
    public partial class frmMain : Form
    {
        //https://us3.proxysite.com/process.php?d=x5B99FmPCRZLiN7LQFXWwMdJOjQXi39xppqhnXPdt9qnPlCNXEwx&b=1
        //https://us3.proxysite.com/process.php?d=x5B99FmPCRZLiN7LQFXWwMdJOjQXi39xppqhnR%2Fck8r%2BOlKzYlg9&b=1 // Good
        //https://us3.proxysite.com/process.php?d=x5B99FmPCRZLiN7LQFXWwMdJOjQXi39xppqhnTiqmsGuO0GyY11q&b=1 // can take logic

        static string names = string.Empty;
        public frmMain()
        {
            InitializeComponent();
        }
        /*
        private void btnFileBrowser_Click(object sender, EventArgs e)
        {
            ///DialogResult result = openFileDialog1.ShowDialog();
            //if (result == DialogResult.OK)
            //{
            //    txtFileName.Text = openFileDialog1.FileName;
            //}
            ///

            ///
            //// Create server settings to pass connection string, timeout, etc.
            //MongoServerSettings settings = new MongoServerSettings();
            //settings.Server = new MongoServerAddress("localhost", 27017);
            //// Create server object to communicate with our server
            //MongoServer server = new MongoServer(settings);
            //// Get our database instance to reach collections and data
            //var database = server.GetDatabase("MessageDB");
            ///

            ////txtFileName.Text = collection.ToString();

            //Method1().Wait();


            ////txtFileName.Text = MainAsync();
        }
        public string MainAsync()
        {

            var client = new MongoClient("mongodb://localhost:27017");
            var database = client.GetDatabase("mydb");
            var collection = database.GetCollection<Movies>("movies");

            //await collection.InsertOneAsync(new Movies { Name = "Jack" });

            var mov = collection.AsQueryable<Movies>().ToList();
            foreach(var mo in mov)
            {
                names += mo.name;
            }

            //var list = collection.Find<Movies>("Movies").ToListAsync();

            //string nameStr = string.Empty;

            //foreach (var person in list)
            //{
            //    nameStr += " " + person.Name;
            //}
            return names;

        }
        static async Task Method1()
        {
            var conString = "mongodb://localhost:27017";
            var Client = new MongoClient(conString);
            var DB = Client.GetDatabase("mydb");
            var collection = DB.GetCollection<BsonDocument>("movies");
            //var Filter = new BsonDocument("ProductName", "WH-208");
            var list = await collection.AsQueryable().ToList();//.To.Find(Filter).ToListAsync();
            foreach (var dc in list)
            {
                Console.WriteLine(dc);
            }
        }
    */
    }
    /*
    public class Movies
    {
        //[BsonId]
        //public ObjectId Id { get; set; }
        //[BsonElement("name")]
        //public string Name { get; set; }
        public ObjectId Id { get; set; }
        public string name { get; set; }
    }


    //http://www.itprotoday.com/software-development/exploring-mongodb-document-database-primer-net-developers


    //public DataTable GetDataTableFromMongoCursor(MongoCursor cursor)
    //{
    //    if (cursor != null && cursor.Count() > 0)
    //    {

    //        DataTable dt = new DataTable(cursor.ToString());
    //        foreach (BsonDocument doc in cursor)
    //        {

    //            foreach (BsonElement elm in doc.Elements)
    //            {
    //                if (!dt.Columns.Contains(elm.Name))
    //                {
    //                    dt.Columns.Add(new DataColumn(elm.Name));
    //                }

    //            }
    //            DataRow dr = dt.NewRow();
    //            foreach (BsonElement elm in doc.Elements)
    //            {
    //                dr[elm.Name] = elm.Value;

    //            }
    //            dt.Rows.Add(dr);
    //        }
    //        return dt;

    //    }
    //    return null;
    //}
    //http://stackoverflow.com/questions/8612698/how-to-convert-mongodb-bsondocumnet-to-list-of-collection-in-c
    */
}
