﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsvPlayerConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            string fileName = @"C:\Users\OmPrakash.Shakya\Desktop\Sample Files\SampleCSV - For Console.csv";

            using (TextFieldParser parser = new TextFieldParser(fileName))
            {
                parser.CommentTokens = new string[] { "#" };
                parser.SetDelimiters(new string[] { "," });
                parser.HasFieldsEnclosedInQuotes = true;

                // First line is the header line.
                //var headerRow = parser.ReadFields();

                // Add header row in the list of records
                //listOfRecords.Add(headerRow);

                // Loop though all the lines that are actually data rows
                while (!parser.EndOfData)
                {
                    try
                    {
                        string row = string.Empty;
                        string[] fields = parser.ReadFields();
                        foreach (var field in fields)
                        {
                            row += field + " \t ";
                        }
                        Console.Write(row);
                        Console.Write(Environment.NewLine);
                    }
                    catch(MalformedLineException ex)
                    {
                        Console.WriteLine(ex.ToString());
                        Console.Write(Environment.NewLine);
                    }
                }
            }
            Console.Read();
        }
    }
}
