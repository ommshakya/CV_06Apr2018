﻿using Oms.ClassLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting thread....");
            Thread thread = new Thread(new ParameterizedThreadStart(StartExecution));
            thread.Start(null);
            Console.WriteLine("Thread completed.\n\n");

            System.Threading.Thread.Sleep(2* 1000);

            //StartExecution(null);

            Console.Read();

        }

        private static void StartExecution(object obj)
        {
            string fileName = @"D:\python_auto_sample_1.py";
            string interpreter = @"C:\Program Files (x86)\Microsoft Visual Studio\Shared\Anaconda3_64\python.exe";
            string interpreter1 = @"C:\Program Files\Anaconda3\python.exe";

            IExecutionEngine pyengine = new PythonEngine();
            Results result = pyengine.ExecuteScript(interpreter1, fileName);
            ShowResults(result);
        }

        private static void ShowResults(Results result)
        {
            Console.WriteLine("**************************************************");
            Console.WriteLine("Engine type : {0}", result.enginetype);

            Console.WriteLine("\nOutput \n");
            Console.WriteLine(result.output);

            if (!string.IsNullOrEmpty(result.error))
            {
                Console.WriteLine("\nError \n");
                Console.WriteLine(result.error);
            }

            if (!string.IsNullOrEmpty(result.exception))
            {
                Console.WriteLine("\nException \n");
                Console.WriteLine(result.exception);
            }
        }
    }
}
