﻿using System;
using System.Diagnostics;

namespace Oms.ConsoleApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World 1!");
            //run_cmd();

        }
        private static void run_cmd()
        {

            string fileName = @"D:\sample_script_2.py";

            Process p = new Process();
            p.StartInfo = new ProcessStartInfo(@"C:\Program Files\Anaconda3\python.exe", fileName) //C:\Program Files\Anaconda3  //C:\Python27\python.exe
            {
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardError = true
            };
            p.Start();

            string output = p.StandardOutput.ReadToEnd();
            string error = p.StandardError.ReadToEnd();
            p.WaitForExit();

            

            Console.WriteLine("output : "+ output);
            Console.WriteLine("error : " + error);

            Console.ReadLine();

        }
    }
}
