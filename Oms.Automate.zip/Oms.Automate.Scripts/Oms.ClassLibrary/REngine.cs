﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public class REngine : IExecutionEngine
    {
        public Results ExecuteScript(string interpreter, string scriptfilepath)
        {
            Process p = new Process();
            p.StartInfo = new ProcessStartInfo(interpreter, scriptfilepath)
            {
                RedirectStandardOutput = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardError = true
            };
            p.Start();

            string output = p.StandardOutput.ReadToEnd();
            string error = p.StandardError.ReadToEnd();
            p.WaitForExit();

            var results = new Results();
            results.enginetype = this.GetType().ToString();// "R engine";// 
            results.output = output; ;
            results.error = error;
            results.exception = null;

            return results;
        }
    }
}
