﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public interface IJobsEngine
    {
        string ScheduleJob(Job job);
        bool UpdateJob(Job job);
        IEnumerable<Job> GetAllJobs();
    }
}
