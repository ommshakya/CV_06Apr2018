﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public class FileLogger : ILogger
    {
        private DateTime CurrentDate { get { return DateTime.Now; } }
        public void WriteError(string error)
        {
            WriteMessage(error, true, false);
        }

        public void WriteLog(string log)
        {
            WriteMessage(log, true, false);
        }
        public void WriteEngineLog(string path, string log)
        {
            WriteEngineMessage(path, log, false);
        }

        private void WriteMessage(string message, bool isLog, bool appendBlankLine = true)
        {
            try
            {
                string fullFilePath = string.Empty;
                if(isLog)
                    fullFilePath = AppDomain.CurrentDomain.BaseDirectory + "Logs\\" + "LogFile.txt";
                else
                    fullFilePath = AppDomain.CurrentDomain.BaseDirectory + "Logs\\" + "ErrorFile.txt";

                if (!Directory.Exists(Path.GetDirectoryName(fullFilePath)))
                    Directory.CreateDirectory(Path.GetDirectoryName(fullFilePath));

                if (!File.Exists(fullFilePath))
                    using (FileStream fs = File.Create(fullFilePath)) { fs.Close(); }

                if (File.Exists(fullFilePath))
                    using (StreamWriter sw = File.AppendText(fullFilePath))
                    {
                        sw.WriteLine(CurrentDate.ToString() + "\t" + message.Trim());
                        //sw.WriteLine();
                        if (appendBlankLine)
                            sw.WriteLine();
                        sw.Close();
                    }
            }
         catch(Exception ex)
            {
                throw ex;
            }
        }
        private void WriteEngineMessage(string fileName, string message, bool appendBlankLine = true)
        {

            try
            {
                string folder = AppDomain.CurrentDomain.BaseDirectory + "Logs\\";
                string fullFilePath = Path.Combine(folder, fileName);

                if (!Directory.Exists(Path.GetDirectoryName(fullFilePath)))
                    Directory.CreateDirectory(Path.GetDirectoryName(fullFilePath));

                if (!File.Exists(fullFilePath))
                    using (FileStream fs = File.Create(fullFilePath)) { fs.Close(); }

                if (File.Exists(fullFilePath))
                    using (StreamWriter sw = File.AppendText(fullFilePath))
                    {
                        sw.WriteLine(CurrentDate.ToString() + "\t" + message.Trim());
                        //sw.WriteLine();
                        if (appendBlankLine)
                            sw.WriteLine();
                        sw.Close();
                    }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
