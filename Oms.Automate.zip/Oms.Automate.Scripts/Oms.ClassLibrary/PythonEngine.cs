﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public class PythonEngine:IExecutionEngine
    {
        public Results ExecuteScript(string interpreter, string scriptfilepath)
        {
            var results = new Results();
            try
            {
                Console.WriteLine("Starting process...");
                Process p = new Process();
                p.StartInfo = new ProcessStartInfo(interpreter, scriptfilepath)
                {
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardError = true
                };
                p.Start();

                Console.WriteLine("Started...");

                string output = p.StandardOutput.ReadToEnd();
                string error = p.StandardError.ReadToEnd();
                p.WaitForExit();
                Console.WriteLine("collecting results...");

                results.enginetype = this.GetType().ToString();//"Python engine";//
                results.output = output; ;
                results.error = error;
                results.exception = null;

                Console.WriteLine("output: " + results);

                p.Close();
                p.Dispose();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
            return results;
        }
    }
}
