﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;


namespace Oms.ClassLibrary
{
    public class JobsEngineFiles : IJobsEngine
    {
        private string SpecialFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "OmsAutomateScripts");

        public string ScheduleJob(Job job)
        {
            //create a file with the name: ScriptType-IsActive-Id
            string fileName = new JobProcessor().CreateId(job);
            fileName = Path.Combine(SpecialFolder, fileName + ".txt");

            var jsonJob = new JavaScriptSerializer().Serialize(job);
            //var obj = Newtonsoft.Json.JsonConvert.DeserializeObject<Lad>(jsonString );

            if (!File.Exists(fileName))
            {
                using (StreamWriter sw = File.CreateText(fileName))
                {
                    sw.Write(jsonJob);
                }
            }
            return fileName;
        }
        public bool UpdateJob(Job job)
        {
            //update the NextSchedule of job in the saved file
            return true;
        }
        public IEnumerable<Job> GetAllJobs()
        {
            List<Job> list = new List<Job>();
            DirectoryInfo dir = new DirectoryInfo(SpecialFolder);
            
            string[] jobFiles = Directory.GetFiles(SpecialFolder);

            foreach (string file in jobFiles)
            {
                if (System.IO.File.Exists(file))
                {
                    string jsonJob = System.IO.File.ReadAllText(file);
                    var job = new JavaScriptSerializer().Deserialize<Job>(jsonJob);
                    list.Add(job);
                }
            }

            return list.AsEnumerable();
        }
    }
}
