﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public class FileFilters
    {
        public const string PythonFileFilter = "Python|*.py";
        public const string RFileFilter = "R|*.r";
        public const string InterpreterFilter = "Executable|*.exe";
    }
}
