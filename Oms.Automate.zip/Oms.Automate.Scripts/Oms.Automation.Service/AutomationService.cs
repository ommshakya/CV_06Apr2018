﻿using Oms.ClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;

namespace Oms.Automation.Service
{
    public partial class AutomationService : ServiceBase
    {
        public AutomationService()
        {
            InitializeComponent();
        }
        private System.Timers.Timer timerMain = null;
        private ILogger _logger = new FileLogger();
        private IJobsEngine _jobsEngine = new JobsEngineFiles();

        protected override void OnStart(string[] args)
        {
            timerMain = new System.Timers.Timer();
            this.timerMain.Interval = 60 * 1000;// 60 seconds
            this.timerMain.Elapsed += new System.Timers.ElapsedEventHandler(this.timerMain_Elapsed);
            this.timerMain.Enabled = true;

            _logger.WriteLog("Service started.");
        }

        protected override void OnStop()
        {
            this.timerMain.Enabled = false;
            _logger.WriteLog("Service stopped.");
        }

        private void timerMain_Elapsed(object sender, ElapsedEventArgs e)
        {
            //TO DO:
            _logger.WriteLog("Service checking for scheduled jobs at this time.");

            //DateTime runTime = Convert.ToDateTime(dRow["time"]);
            //string formatString = "MM/dd/yyyy HH:mm";
            //if (runTime.ToString(formatString) == currTime.ToString(formatString)) ;

            var jobsToStart = _jobsEngine.GetAllJobs().Where(x => x.NextSchedule.Equals("current datetime up to minutes"));

            Parallel.ForEach(jobsToStart, (currentJob) =>
            {
                Console.WriteLine("Thread {2}: Processing {0} [{1}].", new JobProcessor().CreateId(currentJob), currentJob.Id, Thread.CurrentThread.ManagedThreadId);
            });
        }
    }
}
