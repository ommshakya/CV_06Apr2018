﻿using Oms.ClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace Oms.Automate.Scripts
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private ILogger _logger = new FileLogger();
        private IJobsEngine _jobsEngine = new JobsEngineFiles();

        private void ShowBrowsedFile(TextBox textBox, string filter)
        {
            string scriptFile = string.Empty;
            scriptFile = BrowseFile(filter);

            if (!string.IsNullOrEmpty(scriptFile))
            {
                textBox.ReadOnly = false;
                textBox.Text = scriptFile;
                textBox.ReadOnly = true;
            }
            else
            {
                MessageBox.Show("Please browse a valid file.");
            }
        }
        private string BrowseFile(string filter)
        {
            string fileName = string.Empty;
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = filter, ValidateNames = true, Multiselect = false })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    fileName = ofd.FileName;
                }
            }

            return fileName;
        }
        
        private void ShowResults(Results result)
        {
            string res = string.Empty;
            res += "Engine type : " + result.enginetype;

            res += "\nOutput \n";
            res += result.output;

            if (!string.IsNullOrEmpty(result.error))
            {
                res += "\nError \n";
                res += result.error;
            }

            if (!string.IsNullOrEmpty(result.exception))
            {
                res += "\nException \n";
                res += result.exception;
            }

            lblText.Text += res + "\n";
        }

        private void btnBrowseScriptFile_Click(object sender, EventArgs e)
        {
            bool isScriptTypeSelected = false;
            string filter = string.Empty;

            if (rdoBtnPython.Checked)
            {
                isScriptTypeSelected = true;
                filter = FileFilters.PythonFileFilter;
            }
            else if (rdoBtnPython.Checked)
            {
                isScriptTypeSelected = true;
                filter = FileFilters.PythonFileFilter;
            }
            else
                MessageBox.Show("Please choose script type.");

            if (isScriptTypeSelected)
                ShowBrowsedFile(txtScriptFile , filter);
        }

        private void btnChooseInterpreter_Click(object sender, EventArgs e)
        {
            ShowBrowsedFile(txtInterpreter, FileFilters.InterpreterFilter);
        }

        private void btnTestExecution_Click(object sender, EventArgs e)
        {
            _logger.WriteLog("Admin application has started script.");

            string fileName = txtScriptFile.Text;// @"D:\python_auto_sample_1.py";
            string interpreter = txtInterpreter.Text;// @"C:\Program Files (x86)\Microsoft Visual Studio\Shared\Anaconda3_64\python.exe";

            lblText.Text = string.Empty;
            lblText.Text += fileName;
            lblText.Text += "\n" + interpreter + "\n\n";

            IExecutionEngine pyengine = new PythonEngine();
            Results result = pyengine.ExecuteScript(interpreter, fileName);
            ShowResults(result);


            IExecutionEngine rengine = new REngine();
            result = rengine.ExecuteScript(interpreter, fileName);
            ShowResults(result);

            _logger.WriteLog("Admin application has completed script.");

        }

        private void btnScheduleJob_Click(object sender, EventArgs e)
        {
            
            Job job = new Job();
            job.Id = Guid.NewGuid();
            job.Interpreter = txtInterpreter.Text;
            job.IsActive = true;
            job.Name = "Name_" + DateTime.Now.ToString().Replace(':', '-');
            job.Description = "Name_" + DateTime.Now.ToString().Replace(':', '-');
            job.CreatedTime = DateTime.Now;
            job.StartTime = DateTime.Now;
            job.NextSchedule = DateTime.Now; ;
            job.ScriptFilePath = txtScriptFile.Text;
            job.ScriptType = rdoBtnPython.Checked ? "Python" : "R";

            string jobId = _jobsEngine.ScheduleJob(job);
            if(!string.IsNullOrEmpty(jobId))
            {
                label1.Text = "Job scheduled: "+ jobId;
            }

            //List the scheduled jobs
            IEnumerable<Job> jobs = _jobsEngine.GetAllJobs();
            //dispay in interface UI

            /*
            //List the scheduled jobs
            IEnumerable<Job> jobs = _jobsEngine.GetAllJobs();
            int count = jobs.Count();
            foreach(Job job in jobs)
            {
                _logger.WriteLog("--------------------------Start-----------------------------------------");
                string msg = string.Format("Processing {0} [{1}].", new JobProcessor().CreateId(job), job.Id);
                _logger.WriteLog(msg);

                var jsonJob = new JavaScriptSerializer().Serialize(job);
                _logger.WriteLog(jsonJob);
                _logger.WriteLog("Starting thread...");
                Thread thread = new Thread(new ParameterizedThreadStart(StartExecution));
                thread.Start(job);

                _logger.WriteLog("---------------------------End----------------------------------------");

                //System.Threading.Thread.Sleep(4 * 1000);

            }
            
            MessageBox.Show("Completed.");
            */
        }
        private void StartExecution(object obj)
        {
            try
            {
                Job job = (Job)obj;

                _logger.WriteLog("Executing script...");

                IExecutionEngine pyengine = new PythonEngine();
                Results result = pyengine.ExecuteScript(job.Interpreter, job.ScriptFilePath);
                WriteResults(result);


                _logger.WriteLog("Executing script...ends");
            }
            catch
            {
                throw;
            }
        }
        private void WriteResults(Results result)
        {
            string res = string.Empty;
            res += "Engine type : " + result.enginetype;

            res += "\nOutput \n";
            res += result.output;

            if (!string.IsNullOrEmpty(result.error))
            {
                res += "\nError \n";
                res += result.error;
            }

            if (!string.IsNullOrEmpty(result.exception))
            {
                res += "\nException \n";
                res += result.exception;
            }

            _logger.WriteLog(res);
        }
    }
}

