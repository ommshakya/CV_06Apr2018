﻿namespace Oms.Automate.Scripts
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblText = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.txtInterpreter = new System.Windows.Forms.TextBox();
            this.btnChooseInterpreter = new System.Windows.Forms.Button();
            this.txtScriptFile = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.rdoBtnPython = new System.Windows.Forms.RadioButton();
            this.rdoBtnR = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.btnTestExecution = new System.Windows.Forms.Button();
            this.btnBrowseScriptFile1 = new System.Windows.Forms.Button();
            this.btnScheduleJob = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.19174F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.80826F));
            this.tableLayoutPanel1.Controls.Add(this.lblText, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 24);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 55.95855F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 44.04145F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(678, 386);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lblText
            // 
            this.lblText.AutoSize = true;
            this.lblText.Location = new System.Drawing.Point(445, 216);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(35, 13);
            this.lblText.TabIndex = 1;
            this.lblText.Text = "label1";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.70642F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.29358F));
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.txtInterpreter, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.btnChooseInterpreter, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.txtScriptFile, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.label2, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.btnTestExecution, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.btnBrowseScriptFile1, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.btnScheduleJob, 1, 8);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 9;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(436, 210);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Choose interpreter";
            // 
            // txtInterpreter
            // 
            this.txtInterpreter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtInterpreter.Location = new System.Drawing.Point(3, 63);
            this.txtInterpreter.Name = "txtInterpreter";
            this.txtInterpreter.ReadOnly = true;
            this.txtInterpreter.Size = new System.Drawing.Size(310, 20);
            this.txtInterpreter.TabIndex = 1;
            // 
            // btnChooseInterpreter
            // 
            this.btnChooseInterpreter.Location = new System.Drawing.Point(319, 63);
            this.btnChooseInterpreter.Name = "btnChooseInterpreter";
            this.btnChooseInterpreter.Size = new System.Drawing.Size(107, 22);
            this.btnChooseInterpreter.TabIndex = 2;
            this.btnChooseInterpreter.Text = "Choose interpreter";
            this.btnChooseInterpreter.UseVisualStyleBackColor = true;
            this.btnChooseInterpreter.Click += new System.EventHandler(this.btnChooseInterpreter_Click);
            // 
            // txtScriptFile
            // 
            this.txtScriptFile.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtScriptFile.Location = new System.Drawing.Point(3, 123);
            this.txtScriptFile.Name = "txtScriptFile";
            this.txtScriptFile.ReadOnly = true;
            this.txtScriptFile.Size = new System.Drawing.Size(310, 20);
            this.txtScriptFile.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Browse script file(s)";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 131F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.rdoBtnPython, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.rdoBtnR, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(310, 24);
            this.tableLayoutPanel3.TabIndex = 7;
            // 
            // rdoBtnPython
            // 
            this.rdoBtnPython.AutoSize = true;
            this.rdoBtnPython.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rdoBtnPython.Location = new System.Drawing.Point(134, 3);
            this.rdoBtnPython.Name = "rdoBtnPython";
            this.rdoBtnPython.Size = new System.Drawing.Size(83, 18);
            this.rdoBtnPython.TabIndex = 0;
            this.rdoBtnPython.TabStop = true;
            this.rdoBtnPython.Text = "Python";
            this.rdoBtnPython.UseVisualStyleBackColor = true;
            // 
            // rdoBtnR
            // 
            this.rdoBtnR.AutoSize = true;
            this.rdoBtnR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rdoBtnR.Location = new System.Drawing.Point(223, 3);
            this.rdoBtnR.Name = "rdoBtnR";
            this.rdoBtnR.Size = new System.Drawing.Size(84, 18);
            this.rdoBtnR.TabIndex = 1;
            this.rdoBtnR.TabStop = true;
            this.rdoBtnR.Text = "R";
            this.rdoBtnR.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Choose script type";
            // 
            // btnTestExecution
            // 
            this.btnTestExecution.Location = new System.Drawing.Point(3, 163);
            this.btnTestExecution.Name = "btnTestExecution";
            this.btnTestExecution.Size = new System.Drawing.Size(107, 23);
            this.btnTestExecution.TabIndex = 0;
            this.btnTestExecution.Text = "Test execution";
            this.btnTestExecution.UseVisualStyleBackColor = true;
            this.btnTestExecution.Click += new System.EventHandler(this.btnTestExecution_Click);
            // 
            // btnBrowseScriptFile1
            // 
            this.btnBrowseScriptFile1.Location = new System.Drawing.Point(319, 123);
            this.btnBrowseScriptFile1.Name = "btnBrowseScriptFile1";
            this.btnBrowseScriptFile1.Size = new System.Drawing.Size(107, 22);
            this.btnBrowseScriptFile1.TabIndex = 3;
            this.btnBrowseScriptFile1.Text = "Browse script file(s)";
            this.btnBrowseScriptFile1.UseVisualStyleBackColor = true;
            this.btnBrowseScriptFile1.Click += new System.EventHandler(this.btnBrowseScriptFile_Click);
            // 
            // btnScheduleJob
            // 
            this.btnScheduleJob.Location = new System.Drawing.Point(319, 163);
            this.btnScheduleJob.Name = "btnScheduleJob";
            this.btnScheduleJob.Size = new System.Drawing.Size(107, 23);
            this.btnScheduleJob.TabIndex = 8;
            this.btnScheduleJob.Text = "Schedule Job";
            this.btnScheduleJob.UseVisualStyleBackColor = true;
            this.btnScheduleJob.Click += new System.EventHandler(this.btnScheduleJob_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(678, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(678, 410);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnTestExecution;
        private System.Windows.Forms.Label lblText;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtInterpreter;
        private System.Windows.Forms.Button btnChooseInterpreter;
        private System.Windows.Forms.Button btnBrowseScriptFile1;
        private System.Windows.Forms.TextBox txtScriptFile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.RadioButton rdoBtnPython;
        private System.Windows.Forms.RadioButton rdoBtnR;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.Button btnScheduleJob;
    }
}

