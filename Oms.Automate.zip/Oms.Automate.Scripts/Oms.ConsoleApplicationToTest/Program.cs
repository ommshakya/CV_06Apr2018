﻿using Oms.ClassLibrary;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Oms.ConsoleApplicationToTest
{
    class Program
    {
        static ILogger _logger = new FileLogger();
        private static object Threading;

        static void Main(string[] args)
        {
            IJobsEngine _jobsEngine = new JobsEngineFiles();

            /*
            string fileName = @"D:\python_auto_sample_1.py";
            string interpreter = @"C:\Program Files (x86)\Microsoft Visual Studio\Shared\Anaconda3_64\python.exe";
            string interpreter1 = @"C:\Program Files\Anaconda3\python.exe";

            IExecutionEngine pyengine = new PythonEngine();
            Results result = pyengine.ExecuteScript(interpreter1, fileName);
            ShowResults(result);

           
                        Console.WriteLine("****************************************************************");

                        IExecutionEngine rengine = new REngine();
                        result = rengine.ExecuteScript(interpreter, fileName);
                        ShowResults(result);
                        */

            /*
            IJobsEngine _jobsEngine = new JobsEngineFiles();
            //List the scheduled jobs
            IEnumerable<Job> jobs = _jobsEngine.GetAllJobs();
            int count = jobs.Count();

            Parallel.ForEach(jobs, (currentJob) =>
            {
                Console.WriteLine(string.Format("Thread {2}: Processing {0} [{1}]."
                                    , new JobProcessor().CreateId(currentJob), currentJob.Id, System.Threading.Thread.CurrentThread.ManagedThreadId));
                System.Threading.Thread.Sleep(1000);



            });
            */

            ///----------------------------------------------------------------------------------------------------------------------
            //List the scheduled jobs
            IEnumerable<Job> jobs = _jobsEngine.GetAllJobs();
            int count = jobs.Count();
            int i = 1;

            
            foreach (Job job in jobs)
            {
                if (i <= count)
                {
                    string msg = string.Format("Processing {0} [{1}].", new JobProcessor().CreateId(job), job.Id);
                    _logger.WriteLog(msg);

                    var jsonJob = new JavaScriptSerializer().Serialize(job);
                    _logger.WriteLog(jsonJob);

                    _logger.WriteLog("Starting thread...");

                    Thread thread = new Thread(new ParameterizedThreadStart(StartExecution));
                    thread.Start(job);

                    System.Threading.Thread.Sleep(2 * 1000);
                }
                i++;
            }/**/

            

            Console.Read();
        }
        private static void StartExecution(object obj)
        {
            try
            {
                Job job = (Job)obj;
                _logger.WriteLog("Initiated the execution of script...\n\n");
                _logger.WriteLog("\n");

                IExecutionEngine pyengine = new PythonEngine();
                Results result = pyengine.ExecuteScript(job.Interpreter, @job.ScriptFilePath.Replace('1', '3'));

                //Write the output/error or exception of ExecuteScript in a file named as saved file name of jobs

                string fileName = new JobProcessor().CreateId(job);
                fileName = fileName + ".txt";

                WriteResults(result, fileName);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
        private static void WriteResults(Results result, string fileName)
        {
            string res = string.Empty;
            res += "Engine type : " + result.enginetype;

            res +=Environment.NewLine + "\nOutput \n" + Environment.NewLine;
            res += result.output;

            if (!string.IsNullOrEmpty(result.error))
            {
                res += "\nError \n";
                res += result.error;
            }

            if (!string.IsNullOrEmpty(result.exception))
            {
                res += "\nException \n";
                res += result.exception;
            }
            Console.WriteLine(res);

            _logger.WriteEngineLog(fileName, res);
        }

        private static void ShowResults(Results result)
        {
            Console.WriteLine("Engine type : {0}", result.enginetype);

            Console.WriteLine("\nOutput \n");
            Console.WriteLine(result.output);

            if (!string.IsNullOrEmpty(result.error))
            {
                Console.WriteLine("\nError \n");
                Console.WriteLine(result.error);
            }

            if (!string.IsNullOrEmpty(result.exception))
            {
                Console.WriteLine("\nException \n");
                Console.WriteLine(result.exception);
            }
        }
    }
}
